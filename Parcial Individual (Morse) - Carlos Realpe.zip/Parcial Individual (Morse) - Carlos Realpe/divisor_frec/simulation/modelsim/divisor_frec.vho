-- Copyright (C) 1991-2013 Altera Corporation
-- Your use of Altera Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Altera Program License 
-- Subscription Agreement, Altera MegaCore Function License 
-- Agreement, or other applicable license agreement, including, 
-- without limitation, that your use is for the sole purpose of 
-- programming logic devices manufactured by Altera and sold by 
-- Altera or its authorized distributors.  Please refer to the 
-- applicable agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus II 64-Bit"
-- VERSION "Version 13.1.0 Build 162 10/23/2013 SJ Web Edition"

-- DATE "10/12/2026 15:16:30"

-- 
-- Device: Altera EP3C16F484C6 Package FBGA484
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY ALTERA;
LIBRARY CYCLONEIII;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE CYCLONEIII.CYCLONEIII_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	divisor_frec IS
    PORT (
	reloj : IN std_logic;
	rst : IN std_logic;
	reiniciar : IN std_logic;
	tick : OUT std_logic
	);
END divisor_frec;

-- Design Ports Information
-- tick	=>  Location: PIN_V1,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- reiniciar	=>  Location: PIN_N6,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- reloj	=>  Location: PIN_G2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- rst	=>  Location: PIN_G1,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF divisor_frec IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_reloj : std_logic;
SIGNAL ww_rst : std_logic;
SIGNAL ww_reiniciar : std_logic;
SIGNAL ww_tick : std_logic;
SIGNAL \reloj~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \rst~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \tick~output_o\ : std_logic;
SIGNAL \reloj~input_o\ : std_logic;
SIGNAL \reloj~inputclkctrl_outclk\ : std_logic;
SIGNAL \reiniciar~input_o\ : std_logic;
SIGNAL \cuenta[0]~25_combout\ : std_logic;
SIGNAL \rst~input_o\ : std_logic;
SIGNAL \rst~inputclkctrl_outclk\ : std_logic;
SIGNAL \cuenta[24]~27_combout\ : std_logic;
SIGNAL \cuenta[0]~26\ : std_logic;
SIGNAL \cuenta[1]~28_combout\ : std_logic;
SIGNAL \cuenta[1]~29\ : std_logic;
SIGNAL \cuenta[2]~30_combout\ : std_logic;
SIGNAL \cuenta[2]~31\ : std_logic;
SIGNAL \cuenta[3]~32_combout\ : std_logic;
SIGNAL \cuenta[3]~33\ : std_logic;
SIGNAL \cuenta[4]~34_combout\ : std_logic;
SIGNAL \cuenta[4]~35\ : std_logic;
SIGNAL \cuenta[5]~36_combout\ : std_logic;
SIGNAL \cuenta[5]~37\ : std_logic;
SIGNAL \cuenta[6]~38_combout\ : std_logic;
SIGNAL \cuenta[6]~39\ : std_logic;
SIGNAL \cuenta[7]~40_combout\ : std_logic;
SIGNAL \cuenta[7]~41\ : std_logic;
SIGNAL \cuenta[8]~42_combout\ : std_logic;
SIGNAL \cuenta[8]~43\ : std_logic;
SIGNAL \cuenta[9]~44_combout\ : std_logic;
SIGNAL \cuenta[9]~45\ : std_logic;
SIGNAL \cuenta[10]~46_combout\ : std_logic;
SIGNAL \cuenta[10]~47\ : std_logic;
SIGNAL \cuenta[11]~48_combout\ : std_logic;
SIGNAL \cuenta[11]~49\ : std_logic;
SIGNAL \cuenta[12]~50_combout\ : std_logic;
SIGNAL \cuenta[12]~51\ : std_logic;
SIGNAL \cuenta[13]~52_combout\ : std_logic;
SIGNAL \cuenta[13]~53\ : std_logic;
SIGNAL \cuenta[14]~54_combout\ : std_logic;
SIGNAL \cuenta[14]~55\ : std_logic;
SIGNAL \cuenta[15]~56_combout\ : std_logic;
SIGNAL \cuenta[15]~57\ : std_logic;
SIGNAL \cuenta[16]~58_combout\ : std_logic;
SIGNAL \cuenta[16]~59\ : std_logic;
SIGNAL \cuenta[17]~60_combout\ : std_logic;
SIGNAL \cuenta[17]~61\ : std_logic;
SIGNAL \cuenta[18]~62_combout\ : std_logic;
SIGNAL \cuenta[18]~63\ : std_logic;
SIGNAL \cuenta[19]~64_combout\ : std_logic;
SIGNAL \cuenta[19]~65\ : std_logic;
SIGNAL \cuenta[20]~66_combout\ : std_logic;
SIGNAL \cuenta[20]~67\ : std_logic;
SIGNAL \cuenta[21]~68_combout\ : std_logic;
SIGNAL \cuenta[21]~69\ : std_logic;
SIGNAL \cuenta[22]~70_combout\ : std_logic;
SIGNAL \cuenta[22]~71\ : std_logic;
SIGNAL \cuenta[23]~72_combout\ : std_logic;
SIGNAL \Equal0~6_combout\ : std_logic;
SIGNAL \cuenta[23]~73\ : std_logic;
SIGNAL \cuenta[24]~74_combout\ : std_logic;
SIGNAL \Equal0~5_combout\ : std_logic;
SIGNAL \Equal0~1_combout\ : std_logic;
SIGNAL \Equal0~2_combout\ : std_logic;
SIGNAL \Equal0~0_combout\ : std_logic;
SIGNAL \Equal0~3_combout\ : std_logic;
SIGNAL \Equal0~4_combout\ : std_logic;
SIGNAL \Equal0~7_combout\ : std_logic;
SIGNAL \tick~0_combout\ : std_logic;
SIGNAL \tick~reg0_q\ : std_logic;
SIGNAL cuenta : std_logic_vector(24 DOWNTO 0);

BEGIN

ww_reloj <= reloj;
ww_rst <= rst;
ww_reiniciar <= reiniciar;
tick <= ww_tick;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\reloj~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \reloj~input_o\);

\rst~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \rst~input_o\);

-- Location: IOOBUF_X0_Y8_N2
\tick~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \tick~reg0_q\,
	devoe => ww_devoe,
	o => \tick~output_o\);

-- Location: IOIBUF_X0_Y14_N1
\reloj~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_reloj,
	o => \reloj~input_o\);

-- Location: CLKCTRL_G4
\reloj~inputclkctrl\ : cycloneiii_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \reloj~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \reloj~inputclkctrl_outclk\);

-- Location: IOIBUF_X0_Y8_N15
\reiniciar~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_reiniciar,
	o => \reiniciar~input_o\);

-- Location: LCCOMB_X2_Y8_N8
\cuenta[0]~25\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cuenta[0]~25_combout\ = cuenta(0) $ (VCC)
-- \cuenta[0]~26\ = CARRY(cuenta(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => cuenta(0),
	datad => VCC,
	combout => \cuenta[0]~25_combout\,
	cout => \cuenta[0]~26\);

-- Location: IOIBUF_X0_Y14_N8
\rst~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_rst,
	o => \rst~input_o\);

-- Location: CLKCTRL_G2
\rst~inputclkctrl\ : cycloneiii_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \rst~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \rst~inputclkctrl_outclk\);

-- Location: LCCOMB_X2_Y8_N2
\cuenta[24]~27\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cuenta[24]~27_combout\ = (\reiniciar~input_o\) # (!\Equal0~7_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reiniciar~input_o\,
	datad => \Equal0~7_combout\,
	combout => \cuenta[24]~27_combout\);

-- Location: FF_X2_Y8_N9
\cuenta[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \cuenta[0]~25_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	sclr => \cuenta[24]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cuenta(0));

-- Location: LCCOMB_X2_Y8_N10
\cuenta[1]~28\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cuenta[1]~28_combout\ = (cuenta(1) & (!\cuenta[0]~26\)) # (!cuenta(1) & ((\cuenta[0]~26\) # (GND)))
-- \cuenta[1]~29\ = CARRY((!\cuenta[0]~26\) # (!cuenta(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => cuenta(1),
	datad => VCC,
	cin => \cuenta[0]~26\,
	combout => \cuenta[1]~28_combout\,
	cout => \cuenta[1]~29\);

-- Location: FF_X2_Y8_N11
\cuenta[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \cuenta[1]~28_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	sclr => \cuenta[24]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cuenta(1));

-- Location: LCCOMB_X2_Y8_N12
\cuenta[2]~30\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cuenta[2]~30_combout\ = (cuenta(2) & (\cuenta[1]~29\ $ (GND))) # (!cuenta(2) & (!\cuenta[1]~29\ & VCC))
-- \cuenta[2]~31\ = CARRY((cuenta(2) & !\cuenta[1]~29\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => cuenta(2),
	datad => VCC,
	cin => \cuenta[1]~29\,
	combout => \cuenta[2]~30_combout\,
	cout => \cuenta[2]~31\);

-- Location: FF_X2_Y8_N13
\cuenta[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \cuenta[2]~30_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	sclr => \cuenta[24]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cuenta(2));

-- Location: LCCOMB_X2_Y8_N14
\cuenta[3]~32\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cuenta[3]~32_combout\ = (cuenta(3) & (!\cuenta[2]~31\)) # (!cuenta(3) & ((\cuenta[2]~31\) # (GND)))
-- \cuenta[3]~33\ = CARRY((!\cuenta[2]~31\) # (!cuenta(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => cuenta(3),
	datad => VCC,
	cin => \cuenta[2]~31\,
	combout => \cuenta[3]~32_combout\,
	cout => \cuenta[3]~33\);

-- Location: FF_X2_Y8_N15
\cuenta[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \cuenta[3]~32_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	sclr => \cuenta[24]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cuenta(3));

-- Location: LCCOMB_X2_Y8_N16
\cuenta[4]~34\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cuenta[4]~34_combout\ = (cuenta(4) & (\cuenta[3]~33\ $ (GND))) # (!cuenta(4) & (!\cuenta[3]~33\ & VCC))
-- \cuenta[4]~35\ = CARRY((cuenta(4) & !\cuenta[3]~33\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => cuenta(4),
	datad => VCC,
	cin => \cuenta[3]~33\,
	combout => \cuenta[4]~34_combout\,
	cout => \cuenta[4]~35\);

-- Location: FF_X2_Y8_N17
\cuenta[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \cuenta[4]~34_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	sclr => \cuenta[24]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cuenta(4));

-- Location: LCCOMB_X2_Y8_N18
\cuenta[5]~36\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cuenta[5]~36_combout\ = (cuenta(5) & (!\cuenta[4]~35\)) # (!cuenta(5) & ((\cuenta[4]~35\) # (GND)))
-- \cuenta[5]~37\ = CARRY((!\cuenta[4]~35\) # (!cuenta(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => cuenta(5),
	datad => VCC,
	cin => \cuenta[4]~35\,
	combout => \cuenta[5]~36_combout\,
	cout => \cuenta[5]~37\);

-- Location: FF_X2_Y8_N19
\cuenta[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \cuenta[5]~36_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	sclr => \cuenta[24]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cuenta(5));

-- Location: LCCOMB_X2_Y8_N20
\cuenta[6]~38\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cuenta[6]~38_combout\ = (cuenta(6) & (\cuenta[5]~37\ $ (GND))) # (!cuenta(6) & (!\cuenta[5]~37\ & VCC))
-- \cuenta[6]~39\ = CARRY((cuenta(6) & !\cuenta[5]~37\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => cuenta(6),
	datad => VCC,
	cin => \cuenta[5]~37\,
	combout => \cuenta[6]~38_combout\,
	cout => \cuenta[6]~39\);

-- Location: FF_X2_Y8_N21
\cuenta[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \cuenta[6]~38_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	sclr => \cuenta[24]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cuenta(6));

-- Location: LCCOMB_X2_Y8_N22
\cuenta[7]~40\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cuenta[7]~40_combout\ = (cuenta(7) & (!\cuenta[6]~39\)) # (!cuenta(7) & ((\cuenta[6]~39\) # (GND)))
-- \cuenta[7]~41\ = CARRY((!\cuenta[6]~39\) # (!cuenta(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => cuenta(7),
	datad => VCC,
	cin => \cuenta[6]~39\,
	combout => \cuenta[7]~40_combout\,
	cout => \cuenta[7]~41\);

-- Location: FF_X2_Y8_N23
\cuenta[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \cuenta[7]~40_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	sclr => \cuenta[24]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cuenta(7));

-- Location: LCCOMB_X2_Y8_N24
\cuenta[8]~42\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cuenta[8]~42_combout\ = (cuenta(8) & (\cuenta[7]~41\ $ (GND))) # (!cuenta(8) & (!\cuenta[7]~41\ & VCC))
-- \cuenta[8]~43\ = CARRY((cuenta(8) & !\cuenta[7]~41\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => cuenta(8),
	datad => VCC,
	cin => \cuenta[7]~41\,
	combout => \cuenta[8]~42_combout\,
	cout => \cuenta[8]~43\);

-- Location: FF_X2_Y8_N25
\cuenta[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \cuenta[8]~42_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	sclr => \cuenta[24]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cuenta(8));

-- Location: LCCOMB_X2_Y8_N26
\cuenta[9]~44\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cuenta[9]~44_combout\ = (cuenta(9) & (!\cuenta[8]~43\)) # (!cuenta(9) & ((\cuenta[8]~43\) # (GND)))
-- \cuenta[9]~45\ = CARRY((!\cuenta[8]~43\) # (!cuenta(9)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => cuenta(9),
	datad => VCC,
	cin => \cuenta[8]~43\,
	combout => \cuenta[9]~44_combout\,
	cout => \cuenta[9]~45\);

-- Location: FF_X2_Y8_N27
\cuenta[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \cuenta[9]~44_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	sclr => \cuenta[24]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cuenta(9));

-- Location: LCCOMB_X2_Y8_N28
\cuenta[10]~46\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cuenta[10]~46_combout\ = (cuenta(10) & (\cuenta[9]~45\ $ (GND))) # (!cuenta(10) & (!\cuenta[9]~45\ & VCC))
-- \cuenta[10]~47\ = CARRY((cuenta(10) & !\cuenta[9]~45\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => cuenta(10),
	datad => VCC,
	cin => \cuenta[9]~45\,
	combout => \cuenta[10]~46_combout\,
	cout => \cuenta[10]~47\);

-- Location: FF_X2_Y8_N29
\cuenta[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \cuenta[10]~46_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	sclr => \cuenta[24]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cuenta(10));

-- Location: LCCOMB_X2_Y8_N30
\cuenta[11]~48\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cuenta[11]~48_combout\ = (cuenta(11) & (!\cuenta[10]~47\)) # (!cuenta(11) & ((\cuenta[10]~47\) # (GND)))
-- \cuenta[11]~49\ = CARRY((!\cuenta[10]~47\) # (!cuenta(11)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => cuenta(11),
	datad => VCC,
	cin => \cuenta[10]~47\,
	combout => \cuenta[11]~48_combout\,
	cout => \cuenta[11]~49\);

-- Location: FF_X2_Y8_N31
\cuenta[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \cuenta[11]~48_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	sclr => \cuenta[24]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cuenta(11));

-- Location: LCCOMB_X2_Y7_N0
\cuenta[12]~50\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cuenta[12]~50_combout\ = (cuenta(12) & (\cuenta[11]~49\ $ (GND))) # (!cuenta(12) & (!\cuenta[11]~49\ & VCC))
-- \cuenta[12]~51\ = CARRY((cuenta(12) & !\cuenta[11]~49\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => cuenta(12),
	datad => VCC,
	cin => \cuenta[11]~49\,
	combout => \cuenta[12]~50_combout\,
	cout => \cuenta[12]~51\);

-- Location: FF_X2_Y7_N1
\cuenta[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \cuenta[12]~50_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	sclr => \cuenta[24]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cuenta(12));

-- Location: LCCOMB_X2_Y7_N2
\cuenta[13]~52\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cuenta[13]~52_combout\ = (cuenta(13) & (!\cuenta[12]~51\)) # (!cuenta(13) & ((\cuenta[12]~51\) # (GND)))
-- \cuenta[13]~53\ = CARRY((!\cuenta[12]~51\) # (!cuenta(13)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => cuenta(13),
	datad => VCC,
	cin => \cuenta[12]~51\,
	combout => \cuenta[13]~52_combout\,
	cout => \cuenta[13]~53\);

-- Location: FF_X2_Y7_N3
\cuenta[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \cuenta[13]~52_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	sclr => \cuenta[24]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cuenta(13));

-- Location: LCCOMB_X2_Y7_N4
\cuenta[14]~54\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cuenta[14]~54_combout\ = (cuenta(14) & (\cuenta[13]~53\ $ (GND))) # (!cuenta(14) & (!\cuenta[13]~53\ & VCC))
-- \cuenta[14]~55\ = CARRY((cuenta(14) & !\cuenta[13]~53\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => cuenta(14),
	datad => VCC,
	cin => \cuenta[13]~53\,
	combout => \cuenta[14]~54_combout\,
	cout => \cuenta[14]~55\);

-- Location: FF_X2_Y7_N5
\cuenta[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \cuenta[14]~54_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	sclr => \cuenta[24]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cuenta(14));

-- Location: LCCOMB_X2_Y7_N6
\cuenta[15]~56\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cuenta[15]~56_combout\ = (cuenta(15) & (!\cuenta[14]~55\)) # (!cuenta(15) & ((\cuenta[14]~55\) # (GND)))
-- \cuenta[15]~57\ = CARRY((!\cuenta[14]~55\) # (!cuenta(15)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => cuenta(15),
	datad => VCC,
	cin => \cuenta[14]~55\,
	combout => \cuenta[15]~56_combout\,
	cout => \cuenta[15]~57\);

-- Location: FF_X2_Y7_N7
\cuenta[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \cuenta[15]~56_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	sclr => \cuenta[24]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cuenta(15));

-- Location: LCCOMB_X2_Y7_N8
\cuenta[16]~58\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cuenta[16]~58_combout\ = (cuenta(16) & (\cuenta[15]~57\ $ (GND))) # (!cuenta(16) & (!\cuenta[15]~57\ & VCC))
-- \cuenta[16]~59\ = CARRY((cuenta(16) & !\cuenta[15]~57\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => cuenta(16),
	datad => VCC,
	cin => \cuenta[15]~57\,
	combout => \cuenta[16]~58_combout\,
	cout => \cuenta[16]~59\);

-- Location: FF_X2_Y7_N9
\cuenta[16]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \cuenta[16]~58_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	sclr => \cuenta[24]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cuenta(16));

-- Location: LCCOMB_X2_Y7_N10
\cuenta[17]~60\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cuenta[17]~60_combout\ = (cuenta(17) & (!\cuenta[16]~59\)) # (!cuenta(17) & ((\cuenta[16]~59\) # (GND)))
-- \cuenta[17]~61\ = CARRY((!\cuenta[16]~59\) # (!cuenta(17)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => cuenta(17),
	datad => VCC,
	cin => \cuenta[16]~59\,
	combout => \cuenta[17]~60_combout\,
	cout => \cuenta[17]~61\);

-- Location: FF_X2_Y7_N11
\cuenta[17]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \cuenta[17]~60_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	sclr => \cuenta[24]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cuenta(17));

-- Location: LCCOMB_X2_Y7_N12
\cuenta[18]~62\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cuenta[18]~62_combout\ = (cuenta(18) & (\cuenta[17]~61\ $ (GND))) # (!cuenta(18) & (!\cuenta[17]~61\ & VCC))
-- \cuenta[18]~63\ = CARRY((cuenta(18) & !\cuenta[17]~61\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => cuenta(18),
	datad => VCC,
	cin => \cuenta[17]~61\,
	combout => \cuenta[18]~62_combout\,
	cout => \cuenta[18]~63\);

-- Location: FF_X2_Y7_N13
\cuenta[18]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \cuenta[18]~62_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	sclr => \cuenta[24]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cuenta(18));

-- Location: LCCOMB_X2_Y7_N14
\cuenta[19]~64\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cuenta[19]~64_combout\ = (cuenta(19) & (!\cuenta[18]~63\)) # (!cuenta(19) & ((\cuenta[18]~63\) # (GND)))
-- \cuenta[19]~65\ = CARRY((!\cuenta[18]~63\) # (!cuenta(19)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => cuenta(19),
	datad => VCC,
	cin => \cuenta[18]~63\,
	combout => \cuenta[19]~64_combout\,
	cout => \cuenta[19]~65\);

-- Location: FF_X2_Y7_N15
\cuenta[19]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \cuenta[19]~64_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	sclr => \cuenta[24]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cuenta(19));

-- Location: LCCOMB_X2_Y7_N16
\cuenta[20]~66\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cuenta[20]~66_combout\ = (cuenta(20) & (\cuenta[19]~65\ $ (GND))) # (!cuenta(20) & (!\cuenta[19]~65\ & VCC))
-- \cuenta[20]~67\ = CARRY((cuenta(20) & !\cuenta[19]~65\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => cuenta(20),
	datad => VCC,
	cin => \cuenta[19]~65\,
	combout => \cuenta[20]~66_combout\,
	cout => \cuenta[20]~67\);

-- Location: FF_X2_Y7_N17
\cuenta[20]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \cuenta[20]~66_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	sclr => \cuenta[24]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cuenta(20));

-- Location: LCCOMB_X2_Y7_N18
\cuenta[21]~68\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cuenta[21]~68_combout\ = (cuenta(21) & (!\cuenta[20]~67\)) # (!cuenta(21) & ((\cuenta[20]~67\) # (GND)))
-- \cuenta[21]~69\ = CARRY((!\cuenta[20]~67\) # (!cuenta(21)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => cuenta(21),
	datad => VCC,
	cin => \cuenta[20]~67\,
	combout => \cuenta[21]~68_combout\,
	cout => \cuenta[21]~69\);

-- Location: FF_X2_Y7_N19
\cuenta[21]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \cuenta[21]~68_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	sclr => \cuenta[24]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cuenta(21));

-- Location: LCCOMB_X2_Y7_N20
\cuenta[22]~70\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cuenta[22]~70_combout\ = (cuenta(22) & (\cuenta[21]~69\ $ (GND))) # (!cuenta(22) & (!\cuenta[21]~69\ & VCC))
-- \cuenta[22]~71\ = CARRY((cuenta(22) & !\cuenta[21]~69\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => cuenta(22),
	datad => VCC,
	cin => \cuenta[21]~69\,
	combout => \cuenta[22]~70_combout\,
	cout => \cuenta[22]~71\);

-- Location: FF_X2_Y7_N21
\cuenta[22]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \cuenta[22]~70_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	sclr => \cuenta[24]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cuenta(22));

-- Location: LCCOMB_X2_Y7_N22
\cuenta[23]~72\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cuenta[23]~72_combout\ = (cuenta(23) & (!\cuenta[22]~71\)) # (!cuenta(23) & ((\cuenta[22]~71\) # (GND)))
-- \cuenta[23]~73\ = CARRY((!\cuenta[22]~71\) # (!cuenta(23)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => cuenta(23),
	datad => VCC,
	cin => \cuenta[22]~71\,
	combout => \cuenta[23]~72_combout\,
	cout => \cuenta[23]~73\);

-- Location: FF_X2_Y7_N23
\cuenta[23]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \cuenta[23]~72_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	sclr => \cuenta[24]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cuenta(23));

-- Location: LCCOMB_X2_Y7_N30
\Equal0~6\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Equal0~6_combout\ = (cuenta(23)) # (((!cuenta(21)) # (!cuenta(22))) # (!cuenta(20)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => cuenta(23),
	datab => cuenta(20),
	datac => cuenta(22),
	datad => cuenta(21),
	combout => \Equal0~6_combout\);

-- Location: LCCOMB_X2_Y7_N24
\cuenta[24]~74\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cuenta[24]~74_combout\ = \cuenta[23]~73\ $ (!cuenta(24))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datad => cuenta(24),
	cin => \cuenta[23]~73\,
	combout => \cuenta[24]~74_combout\);

-- Location: FF_X2_Y7_N25
\cuenta[24]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \cuenta[24]~74_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	sclr => \cuenta[24]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cuenta(24));

-- Location: LCCOMB_X2_Y7_N28
\Equal0~5\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Equal0~5_combout\ = (((cuenta(17)) # (!cuenta(16))) # (!cuenta(19))) # (!cuenta(18))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111101111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => cuenta(18),
	datab => cuenta(19),
	datac => cuenta(16),
	datad => cuenta(17),
	combout => \Equal0~5_combout\);

-- Location: LCCOMB_X1_Y8_N16
\Equal0~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Equal0~1_combout\ = (cuenta(6)) # (((cuenta(7)) # (!cuenta(5))) # (!cuenta(4)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => cuenta(6),
	datab => cuenta(4),
	datac => cuenta(7),
	datad => cuenta(5),
	combout => \Equal0~1_combout\);

-- Location: LCCOMB_X2_Y8_N4
\Equal0~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Equal0~2_combout\ = (cuenta(9)) # ((cuenta(8)) # ((cuenta(10)) # (!cuenta(11))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111101111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => cuenta(9),
	datab => cuenta(8),
	datac => cuenta(11),
	datad => cuenta(10),
	combout => \Equal0~2_combout\);

-- Location: LCCOMB_X1_Y8_N6
\Equal0~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Equal0~0_combout\ = (((!cuenta(3)) # (!cuenta(2))) # (!cuenta(0))) # (!cuenta(1))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => cuenta(1),
	datab => cuenta(0),
	datac => cuenta(2),
	datad => cuenta(3),
	combout => \Equal0~0_combout\);

-- Location: LCCOMB_X2_Y7_N26
\Equal0~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Equal0~3_combout\ = (cuenta(15)) # (((!cuenta(13)) # (!cuenta(14))) # (!cuenta(12)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => cuenta(15),
	datab => cuenta(12),
	datac => cuenta(14),
	datad => cuenta(13),
	combout => \Equal0~3_combout\);

-- Location: LCCOMB_X2_Y8_N6
\Equal0~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Equal0~4_combout\ = (\Equal0~1_combout\) # ((\Equal0~2_combout\) # ((\Equal0~0_combout\) # (\Equal0~3_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Equal0~1_combout\,
	datab => \Equal0~2_combout\,
	datac => \Equal0~0_combout\,
	datad => \Equal0~3_combout\,
	combout => \Equal0~4_combout\);

-- Location: LCCOMB_X2_Y8_N0
\Equal0~7\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Equal0~7_combout\ = (\Equal0~6_combout\) # (((\Equal0~5_combout\) # (\Equal0~4_combout\)) # (!cuenta(24)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Equal0~6_combout\,
	datab => cuenta(24),
	datac => \Equal0~5_combout\,
	datad => \Equal0~4_combout\,
	combout => \Equal0~7_combout\);

-- Location: LCCOMB_X1_Y8_N28
\tick~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \tick~0_combout\ = (!\reiniciar~input_o\ & !\Equal0~7_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010100000101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reiniciar~input_o\,
	datac => \Equal0~7_combout\,
	combout => \tick~0_combout\);

-- Location: FF_X1_Y8_N29
\tick~reg0\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \tick~0_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \tick~reg0_q\);

ww_tick <= \tick~output_o\;
END structure;


