library ieee;
use ieee.std_logic_1164.all;


entity divisor_frec is
    port (
        reloj     : in  std_logic;
        rst       : in  std_logic;
        reiniciar : in  std_logic; -- limpia la cuenta desde la fsm
        tick      : out std_logic
    );
end divisor_frec;


architecture arch_divisor_frec of divisor_frec is

    constant max_cuenta : integer := 25000000 - 1; -- 0.5 segundos a 50mhz
    signal cuenta       : integer range 0 to max_cuenta;
	 
begin
    process(reloj, rst)
    begin
        if rst = '0' then
            cuenta <= 0;
            tick <= '0';
        elsif rising_edge(reloj) then
            -- si la fsm pide reiniciar, la cuenta empieza limpia
            if reiniciar = '1' then
                cuenta <= 0;
                tick <= '0';
            elsif cuenta = max_cuenta then
                cuenta <= 0;
                tick <= '1'; -- pulso de 0.5s alcanzado
            else
                cuenta <= cuenta + 1;
                tick <= '0';
            end if;
        end if;
    end process;
	 
end arch_divisor_frec;