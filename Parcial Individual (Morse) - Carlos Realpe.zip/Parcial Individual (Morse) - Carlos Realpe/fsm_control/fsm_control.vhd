library ieee;
use ieee.std_logic_1164.all;


entity fsm_control is
    port (
        reloj          : in  std_logic;
        rst            : in  std_logic;
        inicio         : in  std_logic;
        es_cero        : in  std_logic;
        bit_simbolo    : in  std_logic;
        tick           : in  std_logic;
        cargar         : out std_logic;
        habilitar      : out std_logic;
        reiniciar_tick : out std_logic;
        led            : out std_logic
    );
end fsm_control;


architecture arch_fsm_control of fsm_control is

    -- definicion de estados de la maquina
    type tipo_estado is (s_espera, s_evaluar, s_punto, s_raya1, s_raya2, s_raya3, s_pausa);
    signal estado : tipo_estado;
	 
begin
    process(reloj, rst)
    begin
        if rst = '0' then
            estado <= s_espera;
            cargar <= '0';
            habilitar <= '0';
            led <= '0';
            reiniciar_tick <= '1';
        elsif rising_edge(reloj) then
            -- valores predeterminados para evitar latches
            cargar <= '0';
            habilitar <= '0';
            led <= '0';
            reiniciar_tick <= '0'; 

            case estado is
                when s_espera =>
                    reiniciar_tick <= '1'; -- frena el temporizador
                    if inicio = '0' then   -- boton de inicio presionado (activo bajo)
                        cargar <= '1';     -- carga datos en contador y registro
                        estado <= s_evaluar;
                    end if;

                when s_evaluar =>
                    reiniciar_tick <= '1'; 
                    if es_cero = '1' then
                        estado <= s_espera; -- termina la letra
                    else
                        habilitar <= '1';   -- consume un simbolo
                        if bit_simbolo = '0' then
                            estado <= s_punto;
                        else
                            estado <= s_raya1;
                        end if;
                    end if;

                when s_punto =>
                    led <= '1';
                    if tick = '1' then estado <= s_pausa; else estado <= s_punto; end if;

                when s_raya1 =>
                    led <= '1';
                    if tick = '1' then estado <= s_raya2; else estado <= s_raya1; end if;

                when s_raya2 =>
                    led <= '1';
                    if tick = '1' then estado <= s_raya3; else estado <= s_raya2; end if;

                when s_raya3 =>
                    led <= '1';
                    if tick = '1' then estado <= s_pausa; else estado <= s_raya3; end if;

                when s_pausa =>
                    led <= '0'; -- silencio entre simbolos (0.5s)
                    if tick = '1' then estado <= s_evaluar; else estado <= s_pausa; end if;

                when others =>
                    estado <= s_espera;
            end case;
        end if;
    end process;
	 
end arch_fsm_control;