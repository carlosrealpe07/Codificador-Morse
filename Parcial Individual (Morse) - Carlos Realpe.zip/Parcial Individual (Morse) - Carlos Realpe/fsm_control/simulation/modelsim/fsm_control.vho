-- Copyright (C) 1991-2013 Altera Corporation
-- Your use of Altera Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Altera Program License 
-- Subscription Agreement, Altera MegaCore Function License 
-- Agreement, or other applicable license agreement, including, 
-- without limitation, that your use is for the sole purpose of 
-- programming logic devices manufactured by Altera and sold by 
-- Altera or its authorized distributors.  Please refer to the 
-- applicable agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus II 64-Bit"
-- VERSION "Version 13.1.0 Build 162 10/23/2013 SJ Web Edition"

-- DATE "10/12/2026 15:21:24"

-- 
-- Device: Altera EP3C16F484C6 Package FBGA484
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY ALTERA;
LIBRARY CYCLONEIII;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE CYCLONEIII.CYCLONEIII_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	fsm_control IS
    PORT (
	reloj : IN std_logic;
	rst : IN std_logic;
	inicio : IN std_logic;
	es_cero : IN std_logic;
	bit_simbolo : IN std_logic;
	tick : IN std_logic;
	cargar : OUT std_logic;
	habilitar : OUT std_logic;
	reiniciar_tick : OUT std_logic;
	led : OUT std_logic
	);
END fsm_control;

-- Design Ports Information
-- cargar	=>  Location: PIN_P6,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- habilitar	=>  Location: PIN_T4,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- reiniciar_tick	=>  Location: PIN_R5,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- led	=>  Location: PIN_AA2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- inicio	=>  Location: PIN_AA1,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- reloj	=>  Location: PIN_G2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- rst	=>  Location: PIN_G1,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- es_cero	=>  Location: PIN_P7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tick	=>  Location: PIN_V3,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- bit_simbolo	=>  Location: PIN_V4,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF fsm_control IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_reloj : std_logic;
SIGNAL ww_rst : std_logic;
SIGNAL ww_inicio : std_logic;
SIGNAL ww_es_cero : std_logic;
SIGNAL ww_bit_simbolo : std_logic;
SIGNAL ww_tick : std_logic;
SIGNAL ww_cargar : std_logic;
SIGNAL ww_habilitar : std_logic;
SIGNAL ww_reiniciar_tick : std_logic;
SIGNAL ww_led : std_logic;
SIGNAL \reloj~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \rst~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \cargar~output_o\ : std_logic;
SIGNAL \habilitar~output_o\ : std_logic;
SIGNAL \reiniciar_tick~output_o\ : std_logic;
SIGNAL \led~output_o\ : std_logic;
SIGNAL \reloj~input_o\ : std_logic;
SIGNAL \reloj~inputclkctrl_outclk\ : std_logic;
SIGNAL \inicio~input_o\ : std_logic;
SIGNAL \es_cero~input_o\ : std_logic;
SIGNAL \tick~input_o\ : std_logic;
SIGNAL \bit_simbolo~input_o\ : std_logic;
SIGNAL \Selector3~0_combout\ : std_logic;
SIGNAL \Selector3~1_combout\ : std_logic;
SIGNAL \rst~input_o\ : std_logic;
SIGNAL \rst~inputclkctrl_outclk\ : std_logic;
SIGNAL \estado.s_raya1~q\ : std_logic;
SIGNAL \estado.s_raya2~feeder_combout\ : std_logic;
SIGNAL \estado.s_raya2~q\ : std_logic;
SIGNAL \estado.s_raya3~feeder_combout\ : std_logic;
SIGNAL \estado.s_raya3~q\ : std_logic;
SIGNAL \Selector2~0_combout\ : std_logic;
SIGNAL \Selector2~1_combout\ : std_logic;
SIGNAL \estado.s_punto~q\ : std_logic;
SIGNAL \estado~18_combout\ : std_logic;
SIGNAL \estado.s_pausa~q\ : std_logic;
SIGNAL \Selector1~0_combout\ : std_logic;
SIGNAL \estado.s_evaluar~q\ : std_logic;
SIGNAL \Selector0~0_combout\ : std_logic;
SIGNAL \estado.s_espera~q\ : std_logic;
SIGNAL \cargar~0_combout\ : std_logic;
SIGNAL \cargar~reg0_q\ : std_logic;
SIGNAL \habilitar~reg0_q\ : std_logic;
SIGNAL \reiniciar_tick~0_combout\ : std_logic;
SIGNAL \reiniciar_tick~reg0_q\ : std_logic;
SIGNAL \WideOr7~combout\ : std_logic;
SIGNAL \led~reg0_q\ : std_logic;
SIGNAL \ALT_INV_reiniciar_tick~reg0_q\ : std_logic;

BEGIN

ww_reloj <= reloj;
ww_rst <= rst;
ww_inicio <= inicio;
ww_es_cero <= es_cero;
ww_bit_simbolo <= bit_simbolo;
ww_tick <= tick;
cargar <= ww_cargar;
habilitar <= ww_habilitar;
reiniciar_tick <= ww_reiniciar_tick;
led <= ww_led;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\reloj~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \reloj~input_o\);

\rst~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \rst~input_o\);
\ALT_INV_reiniciar_tick~reg0_q\ <= NOT \reiniciar_tick~reg0_q\;

-- Location: IOOBUF_X0_Y4_N9
\cargar~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \cargar~reg0_q\,
	devoe => ww_devoe,
	o => \cargar~output_o\);

-- Location: IOOBUF_X0_Y4_N23
\habilitar~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \habilitar~reg0_q\,
	devoe => ww_devoe,
	o => \habilitar~output_o\);

-- Location: IOOBUF_X0_Y4_N16
\reiniciar_tick~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \ALT_INV_reiniciar_tick~reg0_q\,
	devoe => ww_devoe,
	o => \reiniciar_tick~output_o\);

-- Location: IOOBUF_X0_Y5_N9
\led~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \led~reg0_q\,
	devoe => ww_devoe,
	o => \led~output_o\);

-- Location: IOIBUF_X0_Y14_N1
\reloj~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_reloj,
	o => \reloj~input_o\);

-- Location: CLKCTRL_G4
\reloj~inputclkctrl\ : cycloneiii_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \reloj~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \reloj~inputclkctrl_outclk\);

-- Location: IOIBUF_X0_Y5_N15
\inicio~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_inicio,
	o => \inicio~input_o\);

-- Location: IOIBUF_X0_Y5_N1
\es_cero~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_es_cero,
	o => \es_cero~input_o\);

-- Location: IOIBUF_X0_Y4_N1
\tick~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_tick,
	o => \tick~input_o\);

-- Location: IOIBUF_X0_Y5_N22
\bit_simbolo~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_bit_simbolo,
	o => \bit_simbolo~input_o\);

-- Location: LCCOMB_X1_Y4_N2
\Selector3~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector3~0_combout\ = (!\es_cero~input_o\ & \estado.s_evaluar~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \es_cero~input_o\,
	datad => \estado.s_evaluar~q\,
	combout => \Selector3~0_combout\);

-- Location: LCCOMB_X1_Y4_N26
\Selector3~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector3~1_combout\ = (\bit_simbolo~input_o\ & ((\Selector3~0_combout\) # ((!\tick~input_o\ & \estado.s_raya1~q\)))) # (!\bit_simbolo~input_o\ & (!\tick~input_o\ & (\estado.s_raya1~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bit_simbolo~input_o\,
	datab => \tick~input_o\,
	datac => \estado.s_raya1~q\,
	datad => \Selector3~0_combout\,
	combout => \Selector3~1_combout\);

-- Location: IOIBUF_X0_Y14_N8
\rst~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_rst,
	o => \rst~input_o\);

-- Location: CLKCTRL_G2
\rst~inputclkctrl\ : cycloneiii_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \rst~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \rst~inputclkctrl_outclk\);

-- Location: FF_X1_Y4_N27
\estado.s_raya1\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \Selector3~1_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \estado.s_raya1~q\);

-- Location: LCCOMB_X1_Y4_N28
\estado.s_raya2~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \estado.s_raya2~feeder_combout\ = \estado.s_raya1~q\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \estado.s_raya1~q\,
	combout => \estado.s_raya2~feeder_combout\);

-- Location: FF_X1_Y4_N29
\estado.s_raya2\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \estado.s_raya2~feeder_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	ena => \tick~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \estado.s_raya2~q\);

-- Location: LCCOMB_X1_Y4_N4
\estado.s_raya3~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \estado.s_raya3~feeder_combout\ = \estado.s_raya2~q\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \estado.s_raya2~q\,
	combout => \estado.s_raya3~feeder_combout\);

-- Location: FF_X1_Y4_N5
\estado.s_raya3\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \estado.s_raya3~feeder_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	ena => \tick~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \estado.s_raya3~q\);

-- Location: LCCOMB_X1_Y4_N30
\Selector2~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector2~0_combout\ = (!\bit_simbolo~input_o\ & !\es_cero~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010100000101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bit_simbolo~input_o\,
	datac => \es_cero~input_o\,
	combout => \Selector2~0_combout\);

-- Location: LCCOMB_X1_Y4_N18
\Selector2~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector2~1_combout\ = (\Selector2~0_combout\ & ((\estado.s_evaluar~q\) # ((!\tick~input_o\ & \estado.s_punto~q\)))) # (!\Selector2~0_combout\ & (!\tick~input_o\ & (\estado.s_punto~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Selector2~0_combout\,
	datab => \tick~input_o\,
	datac => \estado.s_punto~q\,
	datad => \estado.s_evaluar~q\,
	combout => \Selector2~1_combout\);

-- Location: FF_X1_Y4_N19
\estado.s_punto\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \Selector2~1_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \estado.s_punto~q\);

-- Location: LCCOMB_X1_Y4_N12
\estado~18\ : cycloneiii_lcell_comb
-- Equation(s):
-- \estado~18_combout\ = (\estado.s_raya3~q\) # (\estado.s_punto~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \estado.s_raya3~q\,
	datad => \estado.s_punto~q\,
	combout => \estado~18_combout\);

-- Location: FF_X1_Y4_N13
\estado.s_pausa\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \estado~18_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	ena => \tick~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \estado.s_pausa~q\);

-- Location: LCCOMB_X1_Y4_N6
\Selector1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector1~0_combout\ = (\inicio~input_o\ & (((\tick~input_o\ & \estado.s_pausa~q\)))) # (!\inicio~input_o\ & (((\tick~input_o\ & \estado.s_pausa~q\)) # (!\estado.s_espera~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000100010001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inicio~input_o\,
	datab => \estado.s_espera~q\,
	datac => \tick~input_o\,
	datad => \estado.s_pausa~q\,
	combout => \Selector1~0_combout\);

-- Location: FF_X1_Y4_N7
\estado.s_evaluar\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \Selector1~0_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \estado.s_evaluar~q\);

-- Location: LCCOMB_X1_Y4_N24
\Selector0~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector0~0_combout\ = (\inicio~input_o\ & (\estado.s_espera~q\ & ((!\estado.s_evaluar~q\) # (!\es_cero~input_o\)))) # (!\inicio~input_o\ & (((!\estado.s_evaluar~q\)) # (!\es_cero~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000111110101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inicio~input_o\,
	datab => \es_cero~input_o\,
	datac => \estado.s_espera~q\,
	datad => \estado.s_evaluar~q\,
	combout => \Selector0~0_combout\);

-- Location: FF_X1_Y4_N25
\estado.s_espera\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \Selector0~0_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \estado.s_espera~q\);

-- Location: LCCOMB_X1_Y4_N16
\cargar~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cargar~0_combout\ = (!\inicio~input_o\ & !\estado.s_espera~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000001010101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inicio~input_o\,
	datad => \estado.s_espera~q\,
	combout => \cargar~0_combout\);

-- Location: FF_X1_Y4_N17
\cargar~reg0\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \cargar~0_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cargar~reg0_q\);

-- Location: FF_X1_Y4_N3
\habilitar~reg0\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \Selector3~0_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \habilitar~reg0_q\);

-- Location: LCCOMB_X1_Y4_N20
\reiniciar_tick~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \reiniciar_tick~0_combout\ = (\estado.s_espera~q\ & !\estado.s_evaluar~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \estado.s_espera~q\,
	datad => \estado.s_evaluar~q\,
	combout => \reiniciar_tick~0_combout\);

-- Location: FF_X1_Y4_N21
\reiniciar_tick~reg0\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \reiniciar_tick~0_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \reiniciar_tick~reg0_q\);

-- Location: LCCOMB_X1_Y4_N10
WideOr7 : cycloneiii_lcell_comb
-- Equation(s):
-- \WideOr7~combout\ = (!\estado.s_evaluar~q\ & (!\estado.s_pausa~q\ & \estado.s_espera~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \estado.s_evaluar~q\,
	datac => \estado.s_pausa~q\,
	datad => \estado.s_espera~q\,
	combout => \WideOr7~combout\);

-- Location: FF_X1_Y4_N11
\led~reg0\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \WideOr7~combout\,
	clrn => \rst~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \led~reg0_q\);

ww_cargar <= \cargar~output_o\;

ww_habilitar <= \habilitar~output_o\;

ww_reiniciar_tick <= \reiniciar_tick~output_o\;

ww_led <= \led~output_o\;
END structure;


