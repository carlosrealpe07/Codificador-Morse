library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;


entity cont_longitud is
    port (
        reloj     : in  std_logic;
        rst       : in  std_logic;
        cargar    : in  std_logic;
        habilitar : in  std_logic; -- señal para decrementar
        datos_in  : in  std_logic_vector(2 downto 0);
        es_cero   : out std_logic
    );
end cont_longitud;


architecture arch_cont_longitud of cont_longitud is

    signal cuenta : unsigned(2 downto 0);
	 
begin
    process(reloj, rst)
    begin
        if rst = '0' then
            cuenta <= (others => '0');
        elsif rising_edge(reloj) then
            if cargar = '1' then
                cuenta <= unsigned(datos_in);
            elsif habilitar = '1' and cuenta > 0 then
                cuenta <= cuenta - 1;
            end if;
        end if;
    end process;

    -- avisa a la fsm cuando ya no hay simbolos por leer
    es_cero <= '1' when cuenta = 0 else '0';
	 
end arch_cont_longitud;