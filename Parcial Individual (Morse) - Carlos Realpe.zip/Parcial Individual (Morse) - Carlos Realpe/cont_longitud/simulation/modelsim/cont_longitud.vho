-- Copyright (C) 1991-2013 Altera Corporation
-- Your use of Altera Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Altera Program License 
-- Subscription Agreement, Altera MegaCore Function License 
-- Agreement, or other applicable license agreement, including, 
-- without limitation, that your use is for the sole purpose of 
-- programming logic devices manufactured by Altera and sold by 
-- Altera or its authorized distributors.  Please refer to the 
-- applicable agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus II 64-Bit"
-- VERSION "Version 13.1.0 Build 162 10/23/2013 SJ Web Edition"

-- DATE "10/12/2026 15:17:52"

-- 
-- Device: Altera EP3C16F484C6 Package FBGA484
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY ALTERA;
LIBRARY CYCLONEIII;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE CYCLONEIII.CYCLONEIII_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	cont_longitud IS
    PORT (
	reloj : IN std_logic;
	rst : IN std_logic;
	cargar : IN std_logic;
	habilitar : IN std_logic;
	datos_in : IN std_logic_vector(2 DOWNTO 0);
	es_cero : OUT std_logic
	);
END cont_longitud;

-- Design Ports Information
-- es_cero	=>  Location: PIN_T5,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datos_in[2]	=>  Location: PIN_R6,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- habilitar	=>  Location: PIN_T8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- cargar	=>  Location: PIN_T9,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- reloj	=>  Location: PIN_G2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- rst	=>  Location: PIN_G1,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datos_in[0]	=>  Location: PIN_V6,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datos_in[1]	=>  Location: PIN_R10,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF cont_longitud IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_reloj : std_logic;
SIGNAL ww_rst : std_logic;
SIGNAL ww_cargar : std_logic;
SIGNAL ww_habilitar : std_logic;
SIGNAL ww_datos_in : std_logic_vector(2 DOWNTO 0);
SIGNAL ww_es_cero : std_logic;
SIGNAL \reloj~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \rst~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \es_cero~output_o\ : std_logic;
SIGNAL \reloj~input_o\ : std_logic;
SIGNAL \reloj~inputclkctrl_outclk\ : std_logic;
SIGNAL \habilitar~input_o\ : std_logic;
SIGNAL \cargar~input_o\ : std_logic;
SIGNAL \datos_in[2]~input_o\ : std_logic;
SIGNAL \datos_in[1]~input_o\ : std_logic;
SIGNAL \cuenta[1]~5_combout\ : std_logic;
SIGNAL \cuenta[1]~6_combout\ : std_logic;
SIGNAL \rst~input_o\ : std_logic;
SIGNAL \rst~inputclkctrl_outclk\ : std_logic;
SIGNAL \cuenta[2]~0_combout\ : std_logic;
SIGNAL \cuenta[2]~1_combout\ : std_logic;
SIGNAL \cuenta[0]~3_combout\ : std_logic;
SIGNAL \datos_in[0]~input_o\ : std_logic;
SIGNAL \cuenta[0]~2_combout\ : std_logic;
SIGNAL \cuenta[0]~4_combout\ : std_logic;
SIGNAL \Equal0~0_combout\ : std_logic;
SIGNAL cuenta : std_logic_vector(2 DOWNTO 0);

BEGIN

ww_reloj <= reloj;
ww_rst <= rst;
ww_cargar <= cargar;
ww_habilitar <= habilitar;
ww_datos_in <= datos_in;
es_cero <= ww_es_cero;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\reloj~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \reloj~input_o\);

\rst~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \rst~input_o\);

-- Location: IOOBUF_X0_Y3_N2
\es_cero~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \Equal0~0_combout\,
	devoe => ww_devoe,
	o => \es_cero~output_o\);

-- Location: IOIBUF_X0_Y14_N1
\reloj~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_reloj,
	o => \reloj~input_o\);

-- Location: CLKCTRL_G4
\reloj~inputclkctrl\ : cycloneiii_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \reloj~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \reloj~inputclkctrl_outclk\);

-- Location: IOIBUF_X1_Y0_N22
\habilitar~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_habilitar,
	o => \habilitar~input_o\);

-- Location: IOIBUF_X1_Y0_N8
\cargar~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_cargar,
	o => \cargar~input_o\);

-- Location: IOIBUF_X0_Y3_N8
\datos_in[2]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datos_in(2),
	o => \datos_in[2]~input_o\);

-- Location: IOIBUF_X1_Y0_N15
\datos_in[1]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datos_in(1),
	o => \datos_in[1]~input_o\);

-- Location: LCCOMB_X1_Y3_N18
\cuenta[1]~5\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cuenta[1]~5_combout\ = (\habilitar~input_o\ & ((\cuenta[0]~3_combout\) # (cuenta(1) $ (cuenta(0))))) # (!\habilitar~input_o\ & (cuenta(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111001101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \habilitar~input_o\,
	datab => cuenta(1),
	datac => cuenta(0),
	datad => \cuenta[0]~3_combout\,
	combout => \cuenta[1]~5_combout\);

-- Location: LCCOMB_X1_Y3_N16
\cuenta[1]~6\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cuenta[1]~6_combout\ = (\cargar~input_o\ & ((\datos_in[1]~input_o\) # ((\habilitar~input_o\ & !\cuenta[1]~5_combout\)))) # (!\cargar~input_o\ & (\habilitar~input_o\ $ (((\cuenta[1]~5_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100010111101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \habilitar~input_o\,
	datab => \datos_in[1]~input_o\,
	datac => \cargar~input_o\,
	datad => \cuenta[1]~5_combout\,
	combout => \cuenta[1]~6_combout\);

-- Location: IOIBUF_X0_Y14_N8
\rst~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_rst,
	o => \rst~input_o\);

-- Location: CLKCTRL_G2
\rst~inputclkctrl\ : cycloneiii_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \rst~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \rst~inputclkctrl_outclk\);

-- Location: FF_X1_Y3_N17
\cuenta[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \cuenta[1]~6_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cuenta(1));

-- Location: LCCOMB_X1_Y3_N12
\cuenta[2]~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cuenta[2]~0_combout\ = (cuenta(2) & (((cuenta(1)) # (cuenta(0))) # (!\habilitar~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \habilitar~input_o\,
	datab => cuenta(1),
	datac => cuenta(0),
	datad => cuenta(2),
	combout => \cuenta[2]~0_combout\);

-- Location: LCCOMB_X1_Y3_N28
\cuenta[2]~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cuenta[2]~1_combout\ = (\cargar~input_o\ & (\datos_in[2]~input_o\)) # (!\cargar~input_o\ & ((\cuenta[2]~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cargar~input_o\,
	datac => \datos_in[2]~input_o\,
	datad => \cuenta[2]~0_combout\,
	combout => \cuenta[2]~1_combout\);

-- Location: FF_X1_Y3_N29
\cuenta[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \cuenta[2]~1_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cuenta(2));

-- Location: LCCOMB_X1_Y3_N20
\cuenta[0]~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cuenta[0]~3_combout\ = (\cargar~input_o\) # ((!cuenta(2) & (!cuenta(0) & !cuenta(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101010101011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cargar~input_o\,
	datab => cuenta(2),
	datac => cuenta(0),
	datad => cuenta(1),
	combout => \cuenta[0]~3_combout\);

-- Location: IOIBUF_X1_Y0_N1
\datos_in[0]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datos_in(0),
	o => \datos_in[0]~input_o\);

-- Location: LCCOMB_X1_Y3_N6
\cuenta[0]~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cuenta[0]~2_combout\ = (\cargar~input_o\ & (((\datos_in[0]~input_o\)))) # (!\cargar~input_o\ & (!\habilitar~input_o\ & ((cuenta(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \habilitar~input_o\,
	datab => \datos_in[0]~input_o\,
	datac => cuenta(0),
	datad => \cargar~input_o\,
	combout => \cuenta[0]~2_combout\);

-- Location: LCCOMB_X1_Y3_N14
\cuenta[0]~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cuenta[0]~4_combout\ = (\cuenta[0]~2_combout\) # ((\habilitar~input_o\ & (!\cuenta[0]~3_combout\ & !cuenta(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \habilitar~input_o\,
	datab => \cuenta[0]~3_combout\,
	datac => cuenta(0),
	datad => \cuenta[0]~2_combout\,
	combout => \cuenta[0]~4_combout\);

-- Location: FF_X1_Y3_N15
\cuenta[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \cuenta[0]~4_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cuenta(0));

-- Location: LCCOMB_X1_Y3_N26
\Equal0~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Equal0~0_combout\ = (!cuenta(0) & (!cuenta(2) & !cuenta(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000010001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => cuenta(0),
	datab => cuenta(2),
	datad => cuenta(1),
	combout => \Equal0~0_combout\);

ww_es_cero <= \es_cero~output_o\;
END structure;


