-- Copyright (C) 1991-2013 Altera Corporation
-- Your use of Altera Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Altera Program License 
-- Subscription Agreement, Altera MegaCore Function License 
-- Agreement, or other applicable license agreement, including, 
-- without limitation, that your use is for the sole purpose of 
-- programming logic devices manufactured by Altera and sold by 
-- Altera or its authorized distributors.  Please refer to the 
-- applicable agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus II 64-Bit"
-- VERSION "Version 13.1.0 Build 162 10/23/2013 SJ Web Edition"

-- DATE "10/12/2026 15:14:38"

-- 
-- Device: Altera EP3C16F484C6 Package FBGA484
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY CYCLONEIII;
LIBRARY IEEE;
USE CYCLONEIII.CYCLONEIII_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	sel_letra IS
    PORT (
	llaves : IN std_logic_vector(2 DOWNTO 0);
	patron : OUT std_logic_vector(3 DOWNTO 0);
	longitud : OUT std_logic_vector(2 DOWNTO 0)
	);
END sel_letra;

-- Design Ports Information
-- patron[0]	=>  Location: PIN_F15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- patron[1]	=>  Location: PIN_M7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- patron[2]	=>  Location: PIN_AB4,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- patron[3]	=>  Location: PIN_N6,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- longitud[0]	=>  Location: PIN_F7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- longitud[1]	=>  Location: PIN_K8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- longitud[2]	=>  Location: PIN_U1,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- llaves[2]	=>  Location: PIN_R12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- llaves[0]	=>  Location: PIN_L7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- llaves[1]	=>  Location: PIN_V11,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF sel_letra IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_llaves : std_logic_vector(2 DOWNTO 0);
SIGNAL ww_patron : std_logic_vector(3 DOWNTO 0);
SIGNAL ww_longitud : std_logic_vector(2 DOWNTO 0);
SIGNAL \patron[0]~output_o\ : std_logic;
SIGNAL \patron[1]~output_o\ : std_logic;
SIGNAL \patron[2]~output_o\ : std_logic;
SIGNAL \patron[3]~output_o\ : std_logic;
SIGNAL \longitud[0]~output_o\ : std_logic;
SIGNAL \longitud[1]~output_o\ : std_logic;
SIGNAL \longitud[2]~output_o\ : std_logic;
SIGNAL \llaves[0]~input_o\ : std_logic;
SIGNAL \llaves[2]~input_o\ : std_logic;
SIGNAL \llaves[1]~input_o\ : std_logic;
SIGNAL \Mux2~0_combout\ : std_logic;
SIGNAL \Mux1~0_combout\ : std_logic;
SIGNAL \Mux0~0_combout\ : std_logic;
SIGNAL \Mux5~0_combout\ : std_logic;
SIGNAL \Mux4~0_combout\ : std_logic;
SIGNAL \Mux3~0_combout\ : std_logic;
SIGNAL \ALT_INV_Mux1~0_combout\ : std_logic;

BEGIN

ww_llaves <= llaves;
patron <= ww_patron;
longitud <= ww_longitud;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;
\ALT_INV_Mux1~0_combout\ <= NOT \Mux1~0_combout\;

-- Location: IOOBUF_X39_Y29_N16
\patron[0]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => \patron[0]~output_o\);

-- Location: IOOBUF_X0_Y8_N23
\patron[1]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \Mux2~0_combout\,
	devoe => ww_devoe,
	o => \patron[1]~output_o\);

-- Location: IOOBUF_X7_Y0_N2
\patron[2]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \ALT_INV_Mux1~0_combout\,
	devoe => ww_devoe,
	o => \patron[2]~output_o\);

-- Location: IOOBUF_X0_Y8_N16
\patron[3]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \Mux0~0_combout\,
	devoe => ww_devoe,
	o => \patron[3]~output_o\);

-- Location: IOOBUF_X1_Y29_N9
\longitud[0]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \Mux5~0_combout\,
	devoe => ww_devoe,
	o => \longitud[0]~output_o\);

-- Location: IOOBUF_X0_Y22_N9
\longitud[1]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \Mux4~0_combout\,
	devoe => ww_devoe,
	o => \longitud[1]~output_o\);

-- Location: IOOBUF_X0_Y9_N16
\longitud[2]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \Mux3~0_combout\,
	devoe => ww_devoe,
	o => \longitud[2]~output_o\);

-- Location: IOIBUF_X0_Y11_N1
\llaves[0]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_llaves(0),
	o => \llaves[0]~input_o\);

-- Location: IOIBUF_X5_Y0_N29
\llaves[2]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_llaves(2),
	o => \llaves[2]~input_o\);

-- Location: IOIBUF_X19_Y0_N22
\llaves[1]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_llaves(1),
	o => \llaves[1]~input_o\);

-- Location: LCCOMB_X12_Y5_N24
\Mux2~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Mux2~0_combout\ = (\llaves[0]~input_o\ & (\llaves[2]~input_o\ & !\llaves[1]~input_o\)) # (!\llaves[0]~input_o\ & (!\llaves[2]~input_o\ & \llaves[1]~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \llaves[0]~input_o\,
	datac => \llaves[2]~input_o\,
	datad => \llaves[1]~input_o\,
	combout => \Mux2~0_combout\);

-- Location: LCCOMB_X12_Y5_N26
\Mux1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Mux1~0_combout\ = (\llaves[0]~input_o\) # (\llaves[2]~input_o\ $ (\llaves[1]~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111111111010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \llaves[0]~input_o\,
	datac => \llaves[2]~input_o\,
	datad => \llaves[1]~input_o\,
	combout => \Mux1~0_combout\);

-- Location: LCCOMB_X12_Y5_N12
\Mux0~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Mux0~0_combout\ = (\llaves[0]~input_o\ & (!\llaves[2]~input_o\)) # (!\llaves[0]~input_o\ & ((\llaves[1]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101111100001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \llaves[0]~input_o\,
	datac => \llaves[2]~input_o\,
	datad => \llaves[1]~input_o\,
	combout => \Mux0~0_combout\);

-- Location: LCCOMB_X12_Y5_N30
\Mux5~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Mux5~0_combout\ = (\llaves[0]~input_o\ & (!\llaves[2]~input_o\ & \llaves[1]~input_o\)) # (!\llaves[0]~input_o\ & (\llaves[2]~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \llaves[0]~input_o\,
	datac => \llaves[2]~input_o\,
	datad => \llaves[1]~input_o\,
	combout => \Mux5~0_combout\);

-- Location: LCCOMB_X12_Y5_N0
\Mux4~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Mux4~0_combout\ = (\llaves[0]~input_o\ & (!\llaves[2]~input_o\ & \llaves[1]~input_o\)) # (!\llaves[0]~input_o\ & (\llaves[2]~input_o\ $ (!\llaves[1]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101000000101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \llaves[0]~input_o\,
	datac => \llaves[2]~input_o\,
	datad => \llaves[1]~input_o\,
	combout => \Mux4~0_combout\);

-- Location: LCCOMB_X12_Y5_N10
\Mux3~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Mux3~0_combout\ = \llaves[0]~input_o\ $ (((!\llaves[2]~input_o\ & \llaves[1]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \llaves[0]~input_o\,
	datac => \llaves[2]~input_o\,
	datad => \llaves[1]~input_o\,
	combout => \Mux3~0_combout\);

ww_patron(0) <= \patron[0]~output_o\;

ww_patron(1) <= \patron[1]~output_o\;

ww_patron(2) <= \patron[2]~output_o\;

ww_patron(3) <= \patron[3]~output_o\;

ww_longitud(0) <= \longitud[0]~output_o\;

ww_longitud(1) <= \longitud[1]~output_o\;

ww_longitud(2) <= \longitud[2]~output_o\;
END structure;


