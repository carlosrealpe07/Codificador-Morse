library ieee;
use ieee.std_logic_1164.all;


entity sel_letra is
    port (
        llaves   : in  std_logic_vector(2 downto 0);
        patron   : out std_logic_vector(3 downto 0);
        longitud : out std_logic_vector(2 downto 0)
    );
end sel_letra;


architecture arch_sel_letra of sel_letra is

begin
    process(llaves)
    begin
        -- 0=punto, 1=raya. rellenamos con 0 a la derecha
        case llaves is
            when "000"  => patron <= "0100"; longitud <= "010"; -- a (.-)    len: 2
            when "001"  => patron <= "1000"; longitud <= "100"; -- b (-...)  len: 4
            when "010"  => patron <= "1010"; longitud <= "100"; -- c (-.-.)  len: 4
            when "011"  => patron <= "1000"; longitud <= "011"; -- d (-..)   len: 3
            when "100"  => patron <= "0000"; longitud <= "001"; -- e (.)     len: 1
            when "101"  => patron <= "0010"; longitud <= "100"; -- f (..-.)  len: 4
            when "110"  => patron <= "1100"; longitud <= "011"; -- g (--.)   len: 3
            when "111"  => patron <= "0000"; longitud <= "100"; -- h (....)  len: 4
            when others => patron <= "0000"; longitud <= "000";
        end case;
    end process;
	 
end arch_sel_letra;