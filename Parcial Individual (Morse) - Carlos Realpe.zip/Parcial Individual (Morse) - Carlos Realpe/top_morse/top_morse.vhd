library ieee;
use ieee.std_logic_1164.all;


entity top_morse is
    port (
        reloj_50 : in  std_logic;
        llaves   : in  std_logic_vector(2 downto 0); -- SW(2 downto 0)
        botones  : in  std_logic_vector(1 downto 0); -- KEY(0)=rst, KEY(1)=inicio
        led_rojo : out std_logic_vector(0 downto 0)  -- LEDR(0)
    );
end top_morse;


architecture arch_top_morse of top_morse is

    -- 1. declaracion de componentes
    component sel_letra
        port (
            llaves   : in  std_logic_vector(2 downto 0);
            patron   : out std_logic_vector(3 downto 0);
            longitud : out std_logic_vector(2 downto 0)
        );
    end component;

    component divisor_frec
        port (
            reloj     : in  std_logic;
            rst       : in  std_logic;
            reiniciar : in  std_logic;
            tick      : out std_logic
        );
    end component;

    component cont_longitud
        port (
            reloj     : in  std_logic;
            rst       : in  std_logic;
            cargar    : in  std_logic;
            habilitar : in  std_logic;
            datos_in  : in  std_logic_vector(2 downto 0);
            es_cero   : out std_logic
        );
    end component;

    component reg_desplazamiento
        port (
            reloj      : in  std_logic;
            rst        : in  std_logic;
            cargar     : in  std_logic;
            habilitar  : in  std_logic;
            datos_in   : in  std_logic_vector(3 downto 0);
            bit_salida : out std_logic
        );
    end component;

    component fsm_control
        port (
            reloj          : in  std_logic;
            rst            : in  std_logic;
            inicio         : in  std_logic;
            es_cero        : in  std_logic;
            bit_simbolo    : in  std_logic;
            tick           : in  std_logic;
            cargar         : out std_logic;
            habilitar      : out std_logic;
            reiniciar_tick : out std_logic;
            led            : out std_logic
        );
    end component;

    -- 2. señales internas (cables)
    signal c_patron    : std_logic_vector(3 downto 0);
    signal c_longitud  : std_logic_vector(2 downto 0);
    signal c_es_cero   : std_logic;
    signal c_bit_out   : std_logic;
    signal c_tick      : std_logic;
    signal c_cargar    : std_logic;
    signal c_habilitar : std_logic;
    signal c_reiniciar : std_logic;

begin

    -- 3. instanciacion y conexion (port mapping explicito)
    u1_sel_letra: sel_letra
        port map (
            llaves   => llaves,
            patron   => c_patron,
            longitud => c_longitud
        );

    u2_divisor: divisor_frec
        port map (
            reloj     => reloj_50,
            rst       => botones(0),
            reiniciar => c_reiniciar,
            tick      => c_tick
        );

    u3_contador: cont_longitud
        port map (
            reloj     => reloj_50,
            rst       => botones(0),
            cargar    => c_cargar,
            habilitar => c_habilitar,
            datos_in  => c_longitud,
            es_cero   => c_es_cero
        );

    u4_registro: reg_desplazamiento
        port map (
            reloj      => reloj_50,
            rst        => botones(0),
            cargar     => c_cargar,
            habilitar  => c_habilitar,
            datos_in   => c_patron,
            bit_salida => c_bit_out
        );

    u5_fsm: fsm_control
        port map (
            reloj          => reloj_50,
            rst            => botones(0),
            inicio         => botones(1),
            es_cero        => c_es_cero,
            bit_simbolo    => c_bit_out,
            tick           => c_tick,
            cargar         => c_cargar,
            habilitar      => c_habilitar,
            reiniciar_tick => c_reiniciar,
            led            => led_rojo(0)
        );

end arch_top_morse;