-- Copyright (C) 1991-2013 Altera Corporation
-- Your use of Altera Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Altera Program License 
-- Subscription Agreement, Altera MegaCore Function License 
-- Agreement, or other applicable license agreement, including, 
-- without limitation, that your use is for the sole purpose of 
-- programming logic devices manufactured by Altera and sold by 
-- Altera or its authorized distributors.  Please refer to the 
-- applicable agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus II 64-Bit"
-- VERSION "Version 13.1.0 Build 162 10/23/2013 SJ Web Edition"

-- DATE "10/12/2026 16:33:11"

-- 
-- Device: Altera EP3C16F484C6 Package FBGA484
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY ALTERA;
LIBRARY CYCLONEIII;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE CYCLONEIII.CYCLONEIII_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	top_morse IS
    PORT (
	reloj_50 : IN std_logic;
	llaves : IN std_logic_vector(2 DOWNTO 0);
	botones : IN std_logic_vector(1 DOWNTO 0);
	led_rojo : BUFFER std_logic_vector(0 DOWNTO 0)
	);
END top_morse;

-- Design Ports Information
-- led_rojo[0]	=>  Location: PIN_J1,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- reloj_50	=>  Location: PIN_G21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- botones[0]	=>  Location: PIN_H2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- botones[1]	=>  Location: PIN_G3,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- llaves[0]	=>  Location: PIN_J6,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- llaves[2]	=>  Location: PIN_H6,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- llaves[1]	=>  Location: PIN_H5,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF top_morse IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_reloj_50 : std_logic;
SIGNAL ww_llaves : std_logic_vector(2 DOWNTO 0);
SIGNAL ww_botones : std_logic_vector(1 DOWNTO 0);
SIGNAL ww_led_rojo : std_logic_vector(0 DOWNTO 0);
SIGNAL \reloj_50~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \led_rojo[0]~output_o\ : std_logic;
SIGNAL \reloj_50~input_o\ : std_logic;
SIGNAL \reloj_50~inputclkctrl_outclk\ : std_logic;
SIGNAL \llaves[0]~input_o\ : std_logic;
SIGNAL \llaves[2]~input_o\ : std_logic;
SIGNAL \u3_contador|cuenta~2_combout\ : std_logic;
SIGNAL \llaves[1]~input_o\ : std_logic;
SIGNAL \u3_contador|cuenta[2]~0_combout\ : std_logic;
SIGNAL \botones[1]~input_o\ : std_logic;
SIGNAL \u5_fsm|reiniciar_tick~0_combout\ : std_logic;
SIGNAL \botones[0]~input_o\ : std_logic;
SIGNAL \u5_fsm|reiniciar_tick~q\ : std_logic;
SIGNAL \u2_divisor|cuenta[0]~25_combout\ : std_logic;
SIGNAL \u2_divisor|cuenta[18]~27_combout\ : std_logic;
SIGNAL \u2_divisor|cuenta[0]~26\ : std_logic;
SIGNAL \u2_divisor|cuenta[1]~28_combout\ : std_logic;
SIGNAL \u2_divisor|cuenta[1]~29\ : std_logic;
SIGNAL \u2_divisor|cuenta[2]~30_combout\ : std_logic;
SIGNAL \u2_divisor|cuenta[2]~31\ : std_logic;
SIGNAL \u2_divisor|cuenta[3]~32_combout\ : std_logic;
SIGNAL \u2_divisor|cuenta[3]~33\ : std_logic;
SIGNAL \u2_divisor|cuenta[4]~34_combout\ : std_logic;
SIGNAL \u2_divisor|cuenta[4]~35\ : std_logic;
SIGNAL \u2_divisor|cuenta[5]~36_combout\ : std_logic;
SIGNAL \u2_divisor|cuenta[5]~37\ : std_logic;
SIGNAL \u2_divisor|cuenta[6]~38_combout\ : std_logic;
SIGNAL \u2_divisor|cuenta[6]~39\ : std_logic;
SIGNAL \u2_divisor|cuenta[7]~40_combout\ : std_logic;
SIGNAL \u2_divisor|cuenta[7]~41\ : std_logic;
SIGNAL \u2_divisor|cuenta[8]~42_combout\ : std_logic;
SIGNAL \u2_divisor|cuenta[8]~43\ : std_logic;
SIGNAL \u2_divisor|cuenta[9]~44_combout\ : std_logic;
SIGNAL \u2_divisor|cuenta[9]~45\ : std_logic;
SIGNAL \u2_divisor|cuenta[10]~46_combout\ : std_logic;
SIGNAL \u2_divisor|cuenta[10]~47\ : std_logic;
SIGNAL \u2_divisor|cuenta[11]~48_combout\ : std_logic;
SIGNAL \u2_divisor|cuenta[11]~49\ : std_logic;
SIGNAL \u2_divisor|cuenta[12]~50_combout\ : std_logic;
SIGNAL \u2_divisor|cuenta[12]~51\ : std_logic;
SIGNAL \u2_divisor|cuenta[13]~52_combout\ : std_logic;
SIGNAL \u2_divisor|cuenta[13]~53\ : std_logic;
SIGNAL \u2_divisor|cuenta[14]~54_combout\ : std_logic;
SIGNAL \u2_divisor|cuenta[14]~55\ : std_logic;
SIGNAL \u2_divisor|cuenta[15]~56_combout\ : std_logic;
SIGNAL \u2_divisor|cuenta[15]~57\ : std_logic;
SIGNAL \u2_divisor|cuenta[16]~58_combout\ : std_logic;
SIGNAL \u2_divisor|cuenta[16]~59\ : std_logic;
SIGNAL \u2_divisor|cuenta[17]~60_combout\ : std_logic;
SIGNAL \u2_divisor|cuenta[17]~61\ : std_logic;
SIGNAL \u2_divisor|cuenta[18]~62_combout\ : std_logic;
SIGNAL \u2_divisor|cuenta[18]~63\ : std_logic;
SIGNAL \u2_divisor|cuenta[19]~64_combout\ : std_logic;
SIGNAL \u2_divisor|cuenta[19]~65\ : std_logic;
SIGNAL \u2_divisor|cuenta[20]~66_combout\ : std_logic;
SIGNAL \u2_divisor|cuenta[20]~67\ : std_logic;
SIGNAL \u2_divisor|cuenta[21]~68_combout\ : std_logic;
SIGNAL \u2_divisor|cuenta[21]~69\ : std_logic;
SIGNAL \u2_divisor|cuenta[22]~70_combout\ : std_logic;
SIGNAL \u2_divisor|cuenta[22]~71\ : std_logic;
SIGNAL \u2_divisor|cuenta[23]~72_combout\ : std_logic;
SIGNAL \u2_divisor|Equal0~6_combout\ : std_logic;
SIGNAL \u2_divisor|cuenta[23]~73\ : std_logic;
SIGNAL \u2_divisor|cuenta[24]~74_combout\ : std_logic;
SIGNAL \u2_divisor|Equal0~5_combout\ : std_logic;
SIGNAL \u2_divisor|Equal0~2_combout\ : std_logic;
SIGNAL \u2_divisor|Equal0~3_combout\ : std_logic;
SIGNAL \u2_divisor|Equal0~1_combout\ : std_logic;
SIGNAL \u2_divisor|Equal0~0_combout\ : std_logic;
SIGNAL \u2_divisor|Equal0~4_combout\ : std_logic;
SIGNAL \u2_divisor|Equal0~7_combout\ : std_logic;
SIGNAL \u2_divisor|tick~0_combout\ : std_logic;
SIGNAL \u2_divisor|tick~q\ : std_logic;
SIGNAL \u5_fsm|Selector1~0_combout\ : std_logic;
SIGNAL \u5_fsm|estado.s_evaluar~q\ : std_logic;
SIGNAL \u3_contador|cuenta[1]~7_combout\ : std_logic;
SIGNAL \u3_contador|cuenta[1]~8_combout\ : std_logic;
SIGNAL \u5_fsm|habilitar~feeder_combout\ : std_logic;
SIGNAL \u5_fsm|habilitar~q\ : std_logic;
SIGNAL \u3_contador|cuenta[1]~4_combout\ : std_logic;
SIGNAL \u3_contador|cuenta[1]~9_combout\ : std_logic;
SIGNAL \u3_contador|cuenta[1]~1_combout\ : std_logic;
SIGNAL \u5_fsm|Selector0~0_combout\ : std_logic;
SIGNAL \u5_fsm|estado.s_espera~q\ : std_logic;
SIGNAL \u5_fsm|Selector1~1_combout\ : std_logic;
SIGNAL \u5_fsm|cargar~q\ : std_logic;
SIGNAL \u3_contador|cuenta[0]~5_combout\ : std_logic;
SIGNAL \u3_contador|cuenta[0]~6_combout\ : std_logic;
SIGNAL \u3_contador|cuenta[2]~3_combout\ : std_logic;
SIGNAL \u5_fsm|habilitar~0_combout\ : std_logic;
SIGNAL \u4_registro|registro[3]~0_combout\ : std_logic;
SIGNAL \u1_sel_letra|Mux2~0_combout\ : std_logic;
SIGNAL \u1_sel_letra|Mux2~1_combout\ : std_logic;
SIGNAL \u4_registro|registro[1]~1_combout\ : std_logic;
SIGNAL \u4_registro|registro~5_combout\ : std_logic;
SIGNAL \u4_registro|registro~3_combout\ : std_logic;
SIGNAL \u4_registro|registro~4_combout\ : std_logic;
SIGNAL \u4_registro|registro[3]~2_combout\ : std_logic;
SIGNAL \u5_fsm|Selector2~0_combout\ : std_logic;
SIGNAL \u5_fsm|estado.s_punto~q\ : std_logic;
SIGNAL \u5_fsm|Selector3~0_combout\ : std_logic;
SIGNAL \u5_fsm|estado.s_raya1~q\ : std_logic;
SIGNAL \u5_fsm|estado.s_raya2~feeder_combout\ : std_logic;
SIGNAL \u5_fsm|estado.s_raya2~q\ : std_logic;
SIGNAL \u5_fsm|estado.s_raya3~feeder_combout\ : std_logic;
SIGNAL \u5_fsm|estado.s_raya3~q\ : std_logic;
SIGNAL \u5_fsm|estado~18_combout\ : std_logic;
SIGNAL \u5_fsm|estado.s_pausa~q\ : std_logic;
SIGNAL \u5_fsm|WideOr7~combout\ : std_logic;
SIGNAL \u5_fsm|led~q\ : std_logic;
SIGNAL \u4_registro|registro\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \u2_divisor|cuenta\ : std_logic_vector(24 DOWNTO 0);
SIGNAL \u3_contador|cuenta\ : std_logic_vector(2 DOWNTO 0);
SIGNAL \u5_fsm|ALT_INV_cargar~q\ : std_logic;

BEGIN

ww_reloj_50 <= reloj_50;
ww_llaves <= llaves;
ww_botones <= botones;
led_rojo <= ww_led_rojo;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\reloj_50~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \reloj_50~input_o\);
\u5_fsm|ALT_INV_cargar~q\ <= NOT \u5_fsm|cargar~q\;

-- Location: IOOBUF_X0_Y20_N9
\led_rojo[0]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \u5_fsm|led~q\,
	devoe => ww_devoe,
	o => \led_rojo[0]~output_o\);

-- Location: IOIBUF_X41_Y15_N1
\reloj_50~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_reloj_50,
	o => \reloj_50~input_o\);

-- Location: CLKCTRL_G9
\reloj_50~inputclkctrl\ : cycloneiii_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \reloj_50~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \reloj_50~inputclkctrl_outclk\);

-- Location: IOIBUF_X0_Y24_N1
\llaves[0]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_llaves(0),
	o => \llaves[0]~input_o\);

-- Location: IOIBUF_X0_Y25_N22
\llaves[2]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_llaves(2),
	o => \llaves[2]~input_o\);

-- Location: LCCOMB_X1_Y23_N28
\u3_contador|cuenta~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u3_contador|cuenta~2_combout\ = \llaves[2]~input_o\ $ (\llaves[0]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \llaves[2]~input_o\,
	datac => \llaves[0]~input_o\,
	combout => \u3_contador|cuenta~2_combout\);

-- Location: IOIBUF_X0_Y27_N1
\llaves[1]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_llaves(1),
	o => \llaves[1]~input_o\);

-- Location: LCCOMB_X1_Y23_N14
\u3_contador|cuenta[2]~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u3_contador|cuenta[2]~0_combout\ = (\llaves[1]~input_o\ & ((!\u3_contador|cuenta~2_combout\))) # (!\llaves[1]~input_o\ & (\llaves[0]~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \llaves[0]~input_o\,
	datab => \u3_contador|cuenta~2_combout\,
	datad => \llaves[1]~input_o\,
	combout => \u3_contador|cuenta[2]~0_combout\);

-- Location: IOIBUF_X0_Y23_N15
\botones[1]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_botones(1),
	o => \botones[1]~input_o\);

-- Location: LCCOMB_X2_Y23_N6
\u5_fsm|reiniciar_tick~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u5_fsm|reiniciar_tick~0_combout\ = (\u5_fsm|estado.s_espera~q\ & !\u5_fsm|estado.s_evaluar~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u5_fsm|estado.s_espera~q\,
	datad => \u5_fsm|estado.s_evaluar~q\,
	combout => \u5_fsm|reiniciar_tick~0_combout\);

-- Location: IOIBUF_X0_Y21_N8
\botones[0]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_botones(0),
	o => \botones[0]~input_o\);

-- Location: FF_X2_Y23_N7
\u5_fsm|reiniciar_tick\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u5_fsm|reiniciar_tick~0_combout\,
	clrn => \botones[0]~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u5_fsm|reiniciar_tick~q\);

-- Location: LCCOMB_X2_Y25_N8
\u2_divisor|cuenta[0]~25\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u2_divisor|cuenta[0]~25_combout\ = \u2_divisor|cuenta\(0) $ (VCC)
-- \u2_divisor|cuenta[0]~26\ = CARRY(\u2_divisor|cuenta\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u2_divisor|cuenta\(0),
	datad => VCC,
	combout => \u2_divisor|cuenta[0]~25_combout\,
	cout => \u2_divisor|cuenta[0]~26\);

-- Location: LCCOMB_X2_Y25_N2
\u2_divisor|cuenta[18]~27\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u2_divisor|cuenta[18]~27_combout\ = (!\u2_divisor|Equal0~7_combout\) # (!\u5_fsm|reiniciar_tick~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u5_fsm|reiniciar_tick~q\,
	datad => \u2_divisor|Equal0~7_combout\,
	combout => \u2_divisor|cuenta[18]~27_combout\);

-- Location: FF_X2_Y25_N9
\u2_divisor|cuenta[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u2_divisor|cuenta[0]~25_combout\,
	clrn => \botones[0]~input_o\,
	sclr => \u2_divisor|cuenta[18]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u2_divisor|cuenta\(0));

-- Location: LCCOMB_X2_Y25_N10
\u2_divisor|cuenta[1]~28\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u2_divisor|cuenta[1]~28_combout\ = (\u2_divisor|cuenta\(1) & (!\u2_divisor|cuenta[0]~26\)) # (!\u2_divisor|cuenta\(1) & ((\u2_divisor|cuenta[0]~26\) # (GND)))
-- \u2_divisor|cuenta[1]~29\ = CARRY((!\u2_divisor|cuenta[0]~26\) # (!\u2_divisor|cuenta\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u2_divisor|cuenta\(1),
	datad => VCC,
	cin => \u2_divisor|cuenta[0]~26\,
	combout => \u2_divisor|cuenta[1]~28_combout\,
	cout => \u2_divisor|cuenta[1]~29\);

-- Location: FF_X2_Y25_N11
\u2_divisor|cuenta[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u2_divisor|cuenta[1]~28_combout\,
	clrn => \botones[0]~input_o\,
	sclr => \u2_divisor|cuenta[18]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u2_divisor|cuenta\(1));

-- Location: LCCOMB_X2_Y25_N12
\u2_divisor|cuenta[2]~30\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u2_divisor|cuenta[2]~30_combout\ = (\u2_divisor|cuenta\(2) & (\u2_divisor|cuenta[1]~29\ $ (GND))) # (!\u2_divisor|cuenta\(2) & (!\u2_divisor|cuenta[1]~29\ & VCC))
-- \u2_divisor|cuenta[2]~31\ = CARRY((\u2_divisor|cuenta\(2) & !\u2_divisor|cuenta[1]~29\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u2_divisor|cuenta\(2),
	datad => VCC,
	cin => \u2_divisor|cuenta[1]~29\,
	combout => \u2_divisor|cuenta[2]~30_combout\,
	cout => \u2_divisor|cuenta[2]~31\);

-- Location: FF_X2_Y25_N13
\u2_divisor|cuenta[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u2_divisor|cuenta[2]~30_combout\,
	clrn => \botones[0]~input_o\,
	sclr => \u2_divisor|cuenta[18]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u2_divisor|cuenta\(2));

-- Location: LCCOMB_X2_Y25_N14
\u2_divisor|cuenta[3]~32\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u2_divisor|cuenta[3]~32_combout\ = (\u2_divisor|cuenta\(3) & (!\u2_divisor|cuenta[2]~31\)) # (!\u2_divisor|cuenta\(3) & ((\u2_divisor|cuenta[2]~31\) # (GND)))
-- \u2_divisor|cuenta[3]~33\ = CARRY((!\u2_divisor|cuenta[2]~31\) # (!\u2_divisor|cuenta\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u2_divisor|cuenta\(3),
	datad => VCC,
	cin => \u2_divisor|cuenta[2]~31\,
	combout => \u2_divisor|cuenta[3]~32_combout\,
	cout => \u2_divisor|cuenta[3]~33\);

-- Location: FF_X2_Y25_N15
\u2_divisor|cuenta[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u2_divisor|cuenta[3]~32_combout\,
	clrn => \botones[0]~input_o\,
	sclr => \u2_divisor|cuenta[18]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u2_divisor|cuenta\(3));

-- Location: LCCOMB_X2_Y25_N16
\u2_divisor|cuenta[4]~34\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u2_divisor|cuenta[4]~34_combout\ = (\u2_divisor|cuenta\(4) & (\u2_divisor|cuenta[3]~33\ $ (GND))) # (!\u2_divisor|cuenta\(4) & (!\u2_divisor|cuenta[3]~33\ & VCC))
-- \u2_divisor|cuenta[4]~35\ = CARRY((\u2_divisor|cuenta\(4) & !\u2_divisor|cuenta[3]~33\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u2_divisor|cuenta\(4),
	datad => VCC,
	cin => \u2_divisor|cuenta[3]~33\,
	combout => \u2_divisor|cuenta[4]~34_combout\,
	cout => \u2_divisor|cuenta[4]~35\);

-- Location: FF_X2_Y25_N17
\u2_divisor|cuenta[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u2_divisor|cuenta[4]~34_combout\,
	clrn => \botones[0]~input_o\,
	sclr => \u2_divisor|cuenta[18]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u2_divisor|cuenta\(4));

-- Location: LCCOMB_X2_Y25_N18
\u2_divisor|cuenta[5]~36\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u2_divisor|cuenta[5]~36_combout\ = (\u2_divisor|cuenta\(5) & (!\u2_divisor|cuenta[4]~35\)) # (!\u2_divisor|cuenta\(5) & ((\u2_divisor|cuenta[4]~35\) # (GND)))
-- \u2_divisor|cuenta[5]~37\ = CARRY((!\u2_divisor|cuenta[4]~35\) # (!\u2_divisor|cuenta\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u2_divisor|cuenta\(5),
	datad => VCC,
	cin => \u2_divisor|cuenta[4]~35\,
	combout => \u2_divisor|cuenta[5]~36_combout\,
	cout => \u2_divisor|cuenta[5]~37\);

-- Location: FF_X2_Y25_N19
\u2_divisor|cuenta[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u2_divisor|cuenta[5]~36_combout\,
	clrn => \botones[0]~input_o\,
	sclr => \u2_divisor|cuenta[18]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u2_divisor|cuenta\(5));

-- Location: LCCOMB_X2_Y25_N20
\u2_divisor|cuenta[6]~38\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u2_divisor|cuenta[6]~38_combout\ = (\u2_divisor|cuenta\(6) & (\u2_divisor|cuenta[5]~37\ $ (GND))) # (!\u2_divisor|cuenta\(6) & (!\u2_divisor|cuenta[5]~37\ & VCC))
-- \u2_divisor|cuenta[6]~39\ = CARRY((\u2_divisor|cuenta\(6) & !\u2_divisor|cuenta[5]~37\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u2_divisor|cuenta\(6),
	datad => VCC,
	cin => \u2_divisor|cuenta[5]~37\,
	combout => \u2_divisor|cuenta[6]~38_combout\,
	cout => \u2_divisor|cuenta[6]~39\);

-- Location: FF_X2_Y25_N21
\u2_divisor|cuenta[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u2_divisor|cuenta[6]~38_combout\,
	clrn => \botones[0]~input_o\,
	sclr => \u2_divisor|cuenta[18]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u2_divisor|cuenta\(6));

-- Location: LCCOMB_X2_Y25_N22
\u2_divisor|cuenta[7]~40\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u2_divisor|cuenta[7]~40_combout\ = (\u2_divisor|cuenta\(7) & (!\u2_divisor|cuenta[6]~39\)) # (!\u2_divisor|cuenta\(7) & ((\u2_divisor|cuenta[6]~39\) # (GND)))
-- \u2_divisor|cuenta[7]~41\ = CARRY((!\u2_divisor|cuenta[6]~39\) # (!\u2_divisor|cuenta\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u2_divisor|cuenta\(7),
	datad => VCC,
	cin => \u2_divisor|cuenta[6]~39\,
	combout => \u2_divisor|cuenta[7]~40_combout\,
	cout => \u2_divisor|cuenta[7]~41\);

-- Location: FF_X2_Y25_N23
\u2_divisor|cuenta[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u2_divisor|cuenta[7]~40_combout\,
	clrn => \botones[0]~input_o\,
	sclr => \u2_divisor|cuenta[18]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u2_divisor|cuenta\(7));

-- Location: LCCOMB_X2_Y25_N24
\u2_divisor|cuenta[8]~42\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u2_divisor|cuenta[8]~42_combout\ = (\u2_divisor|cuenta\(8) & (\u2_divisor|cuenta[7]~41\ $ (GND))) # (!\u2_divisor|cuenta\(8) & (!\u2_divisor|cuenta[7]~41\ & VCC))
-- \u2_divisor|cuenta[8]~43\ = CARRY((\u2_divisor|cuenta\(8) & !\u2_divisor|cuenta[7]~41\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u2_divisor|cuenta\(8),
	datad => VCC,
	cin => \u2_divisor|cuenta[7]~41\,
	combout => \u2_divisor|cuenta[8]~42_combout\,
	cout => \u2_divisor|cuenta[8]~43\);

-- Location: FF_X2_Y25_N25
\u2_divisor|cuenta[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u2_divisor|cuenta[8]~42_combout\,
	clrn => \botones[0]~input_o\,
	sclr => \u2_divisor|cuenta[18]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u2_divisor|cuenta\(8));

-- Location: LCCOMB_X2_Y25_N26
\u2_divisor|cuenta[9]~44\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u2_divisor|cuenta[9]~44_combout\ = (\u2_divisor|cuenta\(9) & (!\u2_divisor|cuenta[8]~43\)) # (!\u2_divisor|cuenta\(9) & ((\u2_divisor|cuenta[8]~43\) # (GND)))
-- \u2_divisor|cuenta[9]~45\ = CARRY((!\u2_divisor|cuenta[8]~43\) # (!\u2_divisor|cuenta\(9)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u2_divisor|cuenta\(9),
	datad => VCC,
	cin => \u2_divisor|cuenta[8]~43\,
	combout => \u2_divisor|cuenta[9]~44_combout\,
	cout => \u2_divisor|cuenta[9]~45\);

-- Location: FF_X2_Y25_N27
\u2_divisor|cuenta[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u2_divisor|cuenta[9]~44_combout\,
	clrn => \botones[0]~input_o\,
	sclr => \u2_divisor|cuenta[18]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u2_divisor|cuenta\(9));

-- Location: LCCOMB_X2_Y25_N28
\u2_divisor|cuenta[10]~46\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u2_divisor|cuenta[10]~46_combout\ = (\u2_divisor|cuenta\(10) & (\u2_divisor|cuenta[9]~45\ $ (GND))) # (!\u2_divisor|cuenta\(10) & (!\u2_divisor|cuenta[9]~45\ & VCC))
-- \u2_divisor|cuenta[10]~47\ = CARRY((\u2_divisor|cuenta\(10) & !\u2_divisor|cuenta[9]~45\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u2_divisor|cuenta\(10),
	datad => VCC,
	cin => \u2_divisor|cuenta[9]~45\,
	combout => \u2_divisor|cuenta[10]~46_combout\,
	cout => \u2_divisor|cuenta[10]~47\);

-- Location: FF_X2_Y25_N29
\u2_divisor|cuenta[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u2_divisor|cuenta[10]~46_combout\,
	clrn => \botones[0]~input_o\,
	sclr => \u2_divisor|cuenta[18]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u2_divisor|cuenta\(10));

-- Location: LCCOMB_X2_Y25_N30
\u2_divisor|cuenta[11]~48\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u2_divisor|cuenta[11]~48_combout\ = (\u2_divisor|cuenta\(11) & (!\u2_divisor|cuenta[10]~47\)) # (!\u2_divisor|cuenta\(11) & ((\u2_divisor|cuenta[10]~47\) # (GND)))
-- \u2_divisor|cuenta[11]~49\ = CARRY((!\u2_divisor|cuenta[10]~47\) # (!\u2_divisor|cuenta\(11)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u2_divisor|cuenta\(11),
	datad => VCC,
	cin => \u2_divisor|cuenta[10]~47\,
	combout => \u2_divisor|cuenta[11]~48_combout\,
	cout => \u2_divisor|cuenta[11]~49\);

-- Location: FF_X2_Y25_N31
\u2_divisor|cuenta[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u2_divisor|cuenta[11]~48_combout\,
	clrn => \botones[0]~input_o\,
	sclr => \u2_divisor|cuenta[18]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u2_divisor|cuenta\(11));

-- Location: LCCOMB_X2_Y24_N0
\u2_divisor|cuenta[12]~50\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u2_divisor|cuenta[12]~50_combout\ = (\u2_divisor|cuenta\(12) & (\u2_divisor|cuenta[11]~49\ $ (GND))) # (!\u2_divisor|cuenta\(12) & (!\u2_divisor|cuenta[11]~49\ & VCC))
-- \u2_divisor|cuenta[12]~51\ = CARRY((\u2_divisor|cuenta\(12) & !\u2_divisor|cuenta[11]~49\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u2_divisor|cuenta\(12),
	datad => VCC,
	cin => \u2_divisor|cuenta[11]~49\,
	combout => \u2_divisor|cuenta[12]~50_combout\,
	cout => \u2_divisor|cuenta[12]~51\);

-- Location: FF_X2_Y24_N1
\u2_divisor|cuenta[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u2_divisor|cuenta[12]~50_combout\,
	clrn => \botones[0]~input_o\,
	sclr => \u2_divisor|cuenta[18]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u2_divisor|cuenta\(12));

-- Location: LCCOMB_X2_Y24_N2
\u2_divisor|cuenta[13]~52\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u2_divisor|cuenta[13]~52_combout\ = (\u2_divisor|cuenta\(13) & (!\u2_divisor|cuenta[12]~51\)) # (!\u2_divisor|cuenta\(13) & ((\u2_divisor|cuenta[12]~51\) # (GND)))
-- \u2_divisor|cuenta[13]~53\ = CARRY((!\u2_divisor|cuenta[12]~51\) # (!\u2_divisor|cuenta\(13)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u2_divisor|cuenta\(13),
	datad => VCC,
	cin => \u2_divisor|cuenta[12]~51\,
	combout => \u2_divisor|cuenta[13]~52_combout\,
	cout => \u2_divisor|cuenta[13]~53\);

-- Location: FF_X2_Y24_N3
\u2_divisor|cuenta[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u2_divisor|cuenta[13]~52_combout\,
	clrn => \botones[0]~input_o\,
	sclr => \u2_divisor|cuenta[18]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u2_divisor|cuenta\(13));

-- Location: LCCOMB_X2_Y24_N4
\u2_divisor|cuenta[14]~54\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u2_divisor|cuenta[14]~54_combout\ = (\u2_divisor|cuenta\(14) & (\u2_divisor|cuenta[13]~53\ $ (GND))) # (!\u2_divisor|cuenta\(14) & (!\u2_divisor|cuenta[13]~53\ & VCC))
-- \u2_divisor|cuenta[14]~55\ = CARRY((\u2_divisor|cuenta\(14) & !\u2_divisor|cuenta[13]~53\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u2_divisor|cuenta\(14),
	datad => VCC,
	cin => \u2_divisor|cuenta[13]~53\,
	combout => \u2_divisor|cuenta[14]~54_combout\,
	cout => \u2_divisor|cuenta[14]~55\);

-- Location: FF_X2_Y24_N5
\u2_divisor|cuenta[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u2_divisor|cuenta[14]~54_combout\,
	clrn => \botones[0]~input_o\,
	sclr => \u2_divisor|cuenta[18]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u2_divisor|cuenta\(14));

-- Location: LCCOMB_X2_Y24_N6
\u2_divisor|cuenta[15]~56\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u2_divisor|cuenta[15]~56_combout\ = (\u2_divisor|cuenta\(15) & (!\u2_divisor|cuenta[14]~55\)) # (!\u2_divisor|cuenta\(15) & ((\u2_divisor|cuenta[14]~55\) # (GND)))
-- \u2_divisor|cuenta[15]~57\ = CARRY((!\u2_divisor|cuenta[14]~55\) # (!\u2_divisor|cuenta\(15)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u2_divisor|cuenta\(15),
	datad => VCC,
	cin => \u2_divisor|cuenta[14]~55\,
	combout => \u2_divisor|cuenta[15]~56_combout\,
	cout => \u2_divisor|cuenta[15]~57\);

-- Location: FF_X2_Y24_N7
\u2_divisor|cuenta[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u2_divisor|cuenta[15]~56_combout\,
	clrn => \botones[0]~input_o\,
	sclr => \u2_divisor|cuenta[18]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u2_divisor|cuenta\(15));

-- Location: LCCOMB_X2_Y24_N8
\u2_divisor|cuenta[16]~58\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u2_divisor|cuenta[16]~58_combout\ = (\u2_divisor|cuenta\(16) & (\u2_divisor|cuenta[15]~57\ $ (GND))) # (!\u2_divisor|cuenta\(16) & (!\u2_divisor|cuenta[15]~57\ & VCC))
-- \u2_divisor|cuenta[16]~59\ = CARRY((\u2_divisor|cuenta\(16) & !\u2_divisor|cuenta[15]~57\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u2_divisor|cuenta\(16),
	datad => VCC,
	cin => \u2_divisor|cuenta[15]~57\,
	combout => \u2_divisor|cuenta[16]~58_combout\,
	cout => \u2_divisor|cuenta[16]~59\);

-- Location: FF_X2_Y24_N9
\u2_divisor|cuenta[16]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u2_divisor|cuenta[16]~58_combout\,
	clrn => \botones[0]~input_o\,
	sclr => \u2_divisor|cuenta[18]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u2_divisor|cuenta\(16));

-- Location: LCCOMB_X2_Y24_N10
\u2_divisor|cuenta[17]~60\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u2_divisor|cuenta[17]~60_combout\ = (\u2_divisor|cuenta\(17) & (!\u2_divisor|cuenta[16]~59\)) # (!\u2_divisor|cuenta\(17) & ((\u2_divisor|cuenta[16]~59\) # (GND)))
-- \u2_divisor|cuenta[17]~61\ = CARRY((!\u2_divisor|cuenta[16]~59\) # (!\u2_divisor|cuenta\(17)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u2_divisor|cuenta\(17),
	datad => VCC,
	cin => \u2_divisor|cuenta[16]~59\,
	combout => \u2_divisor|cuenta[17]~60_combout\,
	cout => \u2_divisor|cuenta[17]~61\);

-- Location: FF_X2_Y24_N11
\u2_divisor|cuenta[17]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u2_divisor|cuenta[17]~60_combout\,
	clrn => \botones[0]~input_o\,
	sclr => \u2_divisor|cuenta[18]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u2_divisor|cuenta\(17));

-- Location: LCCOMB_X2_Y24_N12
\u2_divisor|cuenta[18]~62\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u2_divisor|cuenta[18]~62_combout\ = (\u2_divisor|cuenta\(18) & (\u2_divisor|cuenta[17]~61\ $ (GND))) # (!\u2_divisor|cuenta\(18) & (!\u2_divisor|cuenta[17]~61\ & VCC))
-- \u2_divisor|cuenta[18]~63\ = CARRY((\u2_divisor|cuenta\(18) & !\u2_divisor|cuenta[17]~61\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u2_divisor|cuenta\(18),
	datad => VCC,
	cin => \u2_divisor|cuenta[17]~61\,
	combout => \u2_divisor|cuenta[18]~62_combout\,
	cout => \u2_divisor|cuenta[18]~63\);

-- Location: FF_X2_Y24_N13
\u2_divisor|cuenta[18]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u2_divisor|cuenta[18]~62_combout\,
	clrn => \botones[0]~input_o\,
	sclr => \u2_divisor|cuenta[18]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u2_divisor|cuenta\(18));

-- Location: LCCOMB_X2_Y24_N14
\u2_divisor|cuenta[19]~64\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u2_divisor|cuenta[19]~64_combout\ = (\u2_divisor|cuenta\(19) & (!\u2_divisor|cuenta[18]~63\)) # (!\u2_divisor|cuenta\(19) & ((\u2_divisor|cuenta[18]~63\) # (GND)))
-- \u2_divisor|cuenta[19]~65\ = CARRY((!\u2_divisor|cuenta[18]~63\) # (!\u2_divisor|cuenta\(19)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u2_divisor|cuenta\(19),
	datad => VCC,
	cin => \u2_divisor|cuenta[18]~63\,
	combout => \u2_divisor|cuenta[19]~64_combout\,
	cout => \u2_divisor|cuenta[19]~65\);

-- Location: FF_X2_Y24_N15
\u2_divisor|cuenta[19]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u2_divisor|cuenta[19]~64_combout\,
	clrn => \botones[0]~input_o\,
	sclr => \u2_divisor|cuenta[18]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u2_divisor|cuenta\(19));

-- Location: LCCOMB_X2_Y24_N16
\u2_divisor|cuenta[20]~66\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u2_divisor|cuenta[20]~66_combout\ = (\u2_divisor|cuenta\(20) & (\u2_divisor|cuenta[19]~65\ $ (GND))) # (!\u2_divisor|cuenta\(20) & (!\u2_divisor|cuenta[19]~65\ & VCC))
-- \u2_divisor|cuenta[20]~67\ = CARRY((\u2_divisor|cuenta\(20) & !\u2_divisor|cuenta[19]~65\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u2_divisor|cuenta\(20),
	datad => VCC,
	cin => \u2_divisor|cuenta[19]~65\,
	combout => \u2_divisor|cuenta[20]~66_combout\,
	cout => \u2_divisor|cuenta[20]~67\);

-- Location: FF_X2_Y24_N17
\u2_divisor|cuenta[20]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u2_divisor|cuenta[20]~66_combout\,
	clrn => \botones[0]~input_o\,
	sclr => \u2_divisor|cuenta[18]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u2_divisor|cuenta\(20));

-- Location: LCCOMB_X2_Y24_N18
\u2_divisor|cuenta[21]~68\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u2_divisor|cuenta[21]~68_combout\ = (\u2_divisor|cuenta\(21) & (!\u2_divisor|cuenta[20]~67\)) # (!\u2_divisor|cuenta\(21) & ((\u2_divisor|cuenta[20]~67\) # (GND)))
-- \u2_divisor|cuenta[21]~69\ = CARRY((!\u2_divisor|cuenta[20]~67\) # (!\u2_divisor|cuenta\(21)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u2_divisor|cuenta\(21),
	datad => VCC,
	cin => \u2_divisor|cuenta[20]~67\,
	combout => \u2_divisor|cuenta[21]~68_combout\,
	cout => \u2_divisor|cuenta[21]~69\);

-- Location: FF_X2_Y24_N19
\u2_divisor|cuenta[21]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u2_divisor|cuenta[21]~68_combout\,
	clrn => \botones[0]~input_o\,
	sclr => \u2_divisor|cuenta[18]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u2_divisor|cuenta\(21));

-- Location: LCCOMB_X2_Y24_N20
\u2_divisor|cuenta[22]~70\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u2_divisor|cuenta[22]~70_combout\ = (\u2_divisor|cuenta\(22) & (\u2_divisor|cuenta[21]~69\ $ (GND))) # (!\u2_divisor|cuenta\(22) & (!\u2_divisor|cuenta[21]~69\ & VCC))
-- \u2_divisor|cuenta[22]~71\ = CARRY((\u2_divisor|cuenta\(22) & !\u2_divisor|cuenta[21]~69\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u2_divisor|cuenta\(22),
	datad => VCC,
	cin => \u2_divisor|cuenta[21]~69\,
	combout => \u2_divisor|cuenta[22]~70_combout\,
	cout => \u2_divisor|cuenta[22]~71\);

-- Location: FF_X2_Y24_N21
\u2_divisor|cuenta[22]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u2_divisor|cuenta[22]~70_combout\,
	clrn => \botones[0]~input_o\,
	sclr => \u2_divisor|cuenta[18]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u2_divisor|cuenta\(22));

-- Location: LCCOMB_X2_Y24_N22
\u2_divisor|cuenta[23]~72\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u2_divisor|cuenta[23]~72_combout\ = (\u2_divisor|cuenta\(23) & (!\u2_divisor|cuenta[22]~71\)) # (!\u2_divisor|cuenta\(23) & ((\u2_divisor|cuenta[22]~71\) # (GND)))
-- \u2_divisor|cuenta[23]~73\ = CARRY((!\u2_divisor|cuenta[22]~71\) # (!\u2_divisor|cuenta\(23)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u2_divisor|cuenta\(23),
	datad => VCC,
	cin => \u2_divisor|cuenta[22]~71\,
	combout => \u2_divisor|cuenta[23]~72_combout\,
	cout => \u2_divisor|cuenta[23]~73\);

-- Location: FF_X2_Y24_N23
\u2_divisor|cuenta[23]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u2_divisor|cuenta[23]~72_combout\,
	clrn => \botones[0]~input_o\,
	sclr => \u2_divisor|cuenta[18]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u2_divisor|cuenta\(23));

-- Location: LCCOMB_X2_Y24_N30
\u2_divisor|Equal0~6\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u2_divisor|Equal0~6_combout\ = (\u2_divisor|cuenta\(23)) # (((!\u2_divisor|cuenta\(21)) # (!\u2_divisor|cuenta\(22))) # (!\u2_divisor|cuenta\(20)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u2_divisor|cuenta\(23),
	datab => \u2_divisor|cuenta\(20),
	datac => \u2_divisor|cuenta\(22),
	datad => \u2_divisor|cuenta\(21),
	combout => \u2_divisor|Equal0~6_combout\);

-- Location: LCCOMB_X2_Y24_N24
\u2_divisor|cuenta[24]~74\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u2_divisor|cuenta[24]~74_combout\ = \u2_divisor|cuenta[23]~73\ $ (!\u2_divisor|cuenta\(24))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datad => \u2_divisor|cuenta\(24),
	cin => \u2_divisor|cuenta[23]~73\,
	combout => \u2_divisor|cuenta[24]~74_combout\);

-- Location: FF_X2_Y24_N25
\u2_divisor|cuenta[24]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u2_divisor|cuenta[24]~74_combout\,
	clrn => \botones[0]~input_o\,
	sclr => \u2_divisor|cuenta[18]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u2_divisor|cuenta\(24));

-- Location: LCCOMB_X2_Y24_N28
\u2_divisor|Equal0~5\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u2_divisor|Equal0~5_combout\ = (((\u2_divisor|cuenta\(17)) # (!\u2_divisor|cuenta\(16))) # (!\u2_divisor|cuenta\(19))) # (!\u2_divisor|cuenta\(18))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111101111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u2_divisor|cuenta\(18),
	datab => \u2_divisor|cuenta\(19),
	datac => \u2_divisor|cuenta\(16),
	datad => \u2_divisor|cuenta\(17),
	combout => \u2_divisor|Equal0~5_combout\);

-- Location: LCCOMB_X2_Y25_N4
\u2_divisor|Equal0~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u2_divisor|Equal0~2_combout\ = (\u2_divisor|cuenta\(9)) # ((\u2_divisor|cuenta\(10)) # ((\u2_divisor|cuenta\(8)) # (!\u2_divisor|cuenta\(11))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111101111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u2_divisor|cuenta\(9),
	datab => \u2_divisor|cuenta\(10),
	datac => \u2_divisor|cuenta\(11),
	datad => \u2_divisor|cuenta\(8),
	combout => \u2_divisor|Equal0~2_combout\);

-- Location: LCCOMB_X2_Y24_N26
\u2_divisor|Equal0~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u2_divisor|Equal0~3_combout\ = (\u2_divisor|cuenta\(15)) # (((!\u2_divisor|cuenta\(13)) # (!\u2_divisor|cuenta\(14))) # (!\u2_divisor|cuenta\(12)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u2_divisor|cuenta\(15),
	datab => \u2_divisor|cuenta\(12),
	datac => \u2_divisor|cuenta\(14),
	datad => \u2_divisor|cuenta\(13),
	combout => \u2_divisor|Equal0~3_combout\);

-- Location: LCCOMB_X1_Y25_N6
\u2_divisor|Equal0~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u2_divisor|Equal0~1_combout\ = (\u2_divisor|cuenta\(6)) # ((\u2_divisor|cuenta\(7)) # ((!\u2_divisor|cuenta\(5)) # (!\u2_divisor|cuenta\(4))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u2_divisor|cuenta\(6),
	datab => \u2_divisor|cuenta\(7),
	datac => \u2_divisor|cuenta\(4),
	datad => \u2_divisor|cuenta\(5),
	combout => \u2_divisor|Equal0~1_combout\);

-- Location: LCCOMB_X3_Y25_N4
\u2_divisor|Equal0~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u2_divisor|Equal0~0_combout\ = (((!\u2_divisor|cuenta\(0)) # (!\u2_divisor|cuenta\(1))) # (!\u2_divisor|cuenta\(2))) # (!\u2_divisor|cuenta\(3))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u2_divisor|cuenta\(3),
	datab => \u2_divisor|cuenta\(2),
	datac => \u2_divisor|cuenta\(1),
	datad => \u2_divisor|cuenta\(0),
	combout => \u2_divisor|Equal0~0_combout\);

-- Location: LCCOMB_X2_Y25_N6
\u2_divisor|Equal0~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u2_divisor|Equal0~4_combout\ = (\u2_divisor|Equal0~2_combout\) # ((\u2_divisor|Equal0~3_combout\) # ((\u2_divisor|Equal0~1_combout\) # (\u2_divisor|Equal0~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u2_divisor|Equal0~2_combout\,
	datab => \u2_divisor|Equal0~3_combout\,
	datac => \u2_divisor|Equal0~1_combout\,
	datad => \u2_divisor|Equal0~0_combout\,
	combout => \u2_divisor|Equal0~4_combout\);

-- Location: LCCOMB_X2_Y25_N0
\u2_divisor|Equal0~7\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u2_divisor|Equal0~7_combout\ = (\u2_divisor|Equal0~6_combout\) # (((\u2_divisor|Equal0~5_combout\) # (\u2_divisor|Equal0~4_combout\)) # (!\u2_divisor|cuenta\(24)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u2_divisor|Equal0~6_combout\,
	datab => \u2_divisor|cuenta\(24),
	datac => \u2_divisor|Equal0~5_combout\,
	datad => \u2_divisor|Equal0~4_combout\,
	combout => \u2_divisor|Equal0~7_combout\);

-- Location: LCCOMB_X1_Y25_N4
\u2_divisor|tick~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u2_divisor|tick~0_combout\ = (\u5_fsm|reiniciar_tick~q\ & !\u2_divisor|Equal0~7_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u5_fsm|reiniciar_tick~q\,
	datac => \u2_divisor|Equal0~7_combout\,
	combout => \u2_divisor|tick~0_combout\);

-- Location: FF_X1_Y25_N5
\u2_divisor|tick\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u2_divisor|tick~0_combout\,
	clrn => \botones[0]~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u2_divisor|tick~q\);

-- Location: LCCOMB_X2_Y23_N16
\u5_fsm|Selector1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u5_fsm|Selector1~0_combout\ = (\botones[1]~input_o\ & (\u2_divisor|tick~q\ & ((\u5_fsm|estado.s_pausa~q\)))) # (!\botones[1]~input_o\ & (((\u2_divisor|tick~q\ & \u5_fsm|estado.s_pausa~q\)) # (!\u5_fsm|estado.s_espera~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110100000101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \botones[1]~input_o\,
	datab => \u2_divisor|tick~q\,
	datac => \u5_fsm|estado.s_espera~q\,
	datad => \u5_fsm|estado.s_pausa~q\,
	combout => \u5_fsm|Selector1~0_combout\);

-- Location: FF_X2_Y23_N17
\u5_fsm|estado.s_evaluar\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u5_fsm|Selector1~0_combout\,
	clrn => \botones[0]~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u5_fsm|estado.s_evaluar~q\);

-- Location: LCCOMB_X1_Y23_N10
\u3_contador|cuenta[1]~7\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u3_contador|cuenta[1]~7_combout\ = (!\u5_fsm|cargar~q\ & (\u3_contador|cuenta\(0) $ (!\u3_contador|cuenta\(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010011001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u3_contador|cuenta\(0),
	datab => \u3_contador|cuenta\(1),
	datad => \u5_fsm|cargar~q\,
	combout => \u3_contador|cuenta[1]~7_combout\);

-- Location: LCCOMB_X1_Y23_N2
\u3_contador|cuenta[1]~8\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u3_contador|cuenta[1]~8_combout\ = (\u5_fsm|cargar~q\ & ((\llaves[1]~input_o\ & (\llaves[0]~input_o\ $ (\llaves[2]~input_o\))) # (!\llaves[1]~input_o\ & (!\llaves[0]~input_o\ & !\llaves[2]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010100100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \llaves[1]~input_o\,
	datab => \llaves[0]~input_o\,
	datac => \llaves[2]~input_o\,
	datad => \u5_fsm|cargar~q\,
	combout => \u3_contador|cuenta[1]~8_combout\);

-- Location: LCCOMB_X2_Y23_N12
\u5_fsm|habilitar~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u5_fsm|habilitar~feeder_combout\ = \u5_fsm|habilitar~0_combout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u5_fsm|habilitar~0_combout\,
	combout => \u5_fsm|habilitar~feeder_combout\);

-- Location: FF_X2_Y23_N13
\u5_fsm|habilitar\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u5_fsm|habilitar~feeder_combout\,
	clrn => \botones[0]~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u5_fsm|habilitar~q\);

-- Location: LCCOMB_X2_Y23_N4
\u3_contador|cuenta[1]~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u3_contador|cuenta[1]~4_combout\ = (!\u5_fsm|cargar~q\ & ((\u3_contador|cuenta[1]~1_combout\) # (!\u5_fsm|habilitar~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100010001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u5_fsm|habilitar~q\,
	datab => \u5_fsm|cargar~q\,
	datad => \u3_contador|cuenta[1]~1_combout\,
	combout => \u3_contador|cuenta[1]~4_combout\);

-- Location: LCCOMB_X1_Y23_N18
\u3_contador|cuenta[1]~9\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u3_contador|cuenta[1]~9_combout\ = (\u3_contador|cuenta[1]~4_combout\ & (((\u3_contador|cuenta\(1))))) # (!\u3_contador|cuenta[1]~4_combout\ & ((\u3_contador|cuenta[1]~7_combout\) # ((\u3_contador|cuenta[1]~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u3_contador|cuenta[1]~7_combout\,
	datab => \u3_contador|cuenta[1]~8_combout\,
	datac => \u3_contador|cuenta\(1),
	datad => \u3_contador|cuenta[1]~4_combout\,
	combout => \u3_contador|cuenta[1]~9_combout\);

-- Location: FF_X1_Y23_N19
\u3_contador|cuenta[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u3_contador|cuenta[1]~9_combout\,
	clrn => \botones[0]~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u3_contador|cuenta\(1));

-- Location: LCCOMB_X2_Y23_N20
\u3_contador|cuenta[1]~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u3_contador|cuenta[1]~1_combout\ = (!\u3_contador|cuenta\(1) & (!\u3_contador|cuenta\(0) & !\u3_contador|cuenta\(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u3_contador|cuenta\(1),
	datac => \u3_contador|cuenta\(0),
	datad => \u3_contador|cuenta\(2),
	combout => \u3_contador|cuenta[1]~1_combout\);

-- Location: LCCOMB_X2_Y23_N30
\u5_fsm|Selector0~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u5_fsm|Selector0~0_combout\ = (\botones[1]~input_o\ & (\u5_fsm|estado.s_espera~q\ & ((!\u3_contador|cuenta[1]~1_combout\) # (!\u5_fsm|estado.s_evaluar~q\)))) # (!\botones[1]~input_o\ & (((!\u3_contador|cuenta[1]~1_combout\)) # 
-- (!\u5_fsm|estado.s_evaluar~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000111110101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \botones[1]~input_o\,
	datab => \u5_fsm|estado.s_evaluar~q\,
	datac => \u5_fsm|estado.s_espera~q\,
	datad => \u3_contador|cuenta[1]~1_combout\,
	combout => \u5_fsm|Selector0~0_combout\);

-- Location: FF_X2_Y23_N31
\u5_fsm|estado.s_espera\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u5_fsm|Selector0~0_combout\,
	clrn => \botones[0]~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u5_fsm|estado.s_espera~q\);

-- Location: LCCOMB_X2_Y23_N2
\u5_fsm|Selector1~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u5_fsm|Selector1~1_combout\ = (!\u5_fsm|estado.s_espera~q\ & !\botones[1]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010100000101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u5_fsm|estado.s_espera~q\,
	datac => \botones[1]~input_o\,
	combout => \u5_fsm|Selector1~1_combout\);

-- Location: FF_X2_Y23_N3
\u5_fsm|cargar\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u5_fsm|Selector1~1_combout\,
	clrn => \botones[0]~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u5_fsm|cargar~q\);

-- Location: LCCOMB_X1_Y23_N12
\u3_contador|cuenta[0]~5\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u3_contador|cuenta[0]~5_combout\ = (\llaves[2]~input_o\ & (!\llaves[0]~input_o\)) # (!\llaves[2]~input_o\ & (\llaves[0]~input_o\ & \llaves[1]~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \llaves[2]~input_o\,
	datac => \llaves[0]~input_o\,
	datad => \llaves[1]~input_o\,
	combout => \u3_contador|cuenta[0]~5_combout\);

-- Location: LCCOMB_X1_Y23_N6
\u3_contador|cuenta[0]~6\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u3_contador|cuenta[0]~6_combout\ = (\u3_contador|cuenta[1]~4_combout\ & (((\u3_contador|cuenta\(0))))) # (!\u3_contador|cuenta[1]~4_combout\ & ((\u5_fsm|cargar~q\ & (\u3_contador|cuenta[0]~5_combout\)) # (!\u5_fsm|cargar~q\ & 
-- ((!\u3_contador|cuenta\(0))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010001101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u5_fsm|cargar~q\,
	datab => \u3_contador|cuenta[0]~5_combout\,
	datac => \u3_contador|cuenta\(0),
	datad => \u3_contador|cuenta[1]~4_combout\,
	combout => \u3_contador|cuenta[0]~6_combout\);

-- Location: FF_X1_Y23_N7
\u3_contador|cuenta[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u3_contador|cuenta[0]~6_combout\,
	clrn => \botones[0]~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u3_contador|cuenta\(0));

-- Location: LCCOMB_X1_Y23_N8
\u3_contador|cuenta[2]~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u3_contador|cuenta[2]~3_combout\ = (\u3_contador|cuenta\(2) & ((\u3_contador|cuenta\(0)) # ((\u3_contador|cuenta\(1)) # (!\u5_fsm|habilitar~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110010001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u3_contador|cuenta\(0),
	datab => \u3_contador|cuenta\(2),
	datac => \u5_fsm|habilitar~q\,
	datad => \u3_contador|cuenta\(1),
	combout => \u3_contador|cuenta[2]~3_combout\);

-- Location: FF_X1_Y23_N15
\u3_contador|cuenta[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u3_contador|cuenta[2]~0_combout\,
	asdata => \u3_contador|cuenta[2]~3_combout\,
	clrn => \botones[0]~input_o\,
	sload => \u5_fsm|ALT_INV_cargar~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u3_contador|cuenta\(2));

-- Location: LCCOMB_X2_Y23_N26
\u5_fsm|habilitar~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u5_fsm|habilitar~0_combout\ = (\u5_fsm|estado.s_evaluar~q\ & ((\u3_contador|cuenta\(2)) # ((\u3_contador|cuenta\(1)) # (\u3_contador|cuenta\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u3_contador|cuenta\(2),
	datab => \u3_contador|cuenta\(1),
	datac => \u3_contador|cuenta\(0),
	datad => \u5_fsm|estado.s_evaluar~q\,
	combout => \u5_fsm|habilitar~0_combout\);

-- Location: LCCOMB_X1_Y23_N20
\u4_registro|registro[3]~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u4_registro|registro[3]~0_combout\ = (\llaves[0]~input_o\ & (!\llaves[2]~input_o\)) # (!\llaves[0]~input_o\ & ((\llaves[1]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111011101000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \llaves[2]~input_o\,
	datab => \llaves[0]~input_o\,
	datad => \llaves[1]~input_o\,
	combout => \u4_registro|registro[3]~0_combout\);

-- Location: LCCOMB_X1_Y23_N24
\u1_sel_letra|Mux2~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u1_sel_letra|Mux2~0_combout\ = (!\llaves[0]~input_o\ & \llaves[1]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \llaves[0]~input_o\,
	datad => \llaves[1]~input_o\,
	combout => \u1_sel_letra|Mux2~0_combout\);

-- Location: LCCOMB_X1_Y23_N0
\u1_sel_letra|Mux2~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u1_sel_letra|Mux2~1_combout\ = (\llaves[0]~input_o\ & !\llaves[1]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \llaves[0]~input_o\,
	datad => \llaves[1]~input_o\,
	combout => \u1_sel_letra|Mux2~1_combout\);

-- Location: LCCOMB_X1_Y23_N22
\u4_registro|registro[1]~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u4_registro|registro[1]~1_combout\ = (\llaves[2]~input_o\ & ((\u1_sel_letra|Mux2~1_combout\))) # (!\llaves[2]~input_o\ & (\u1_sel_letra|Mux2~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111001000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \llaves[2]~input_o\,
	datab => \u1_sel_letra|Mux2~0_combout\,
	datad => \u1_sel_letra|Mux2~1_combout\,
	combout => \u4_registro|registro[1]~1_combout\);

-- Location: LCCOMB_X1_Y23_N30
\u4_registro|registro~5\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u4_registro|registro~5_combout\ = (!\u5_fsm|habilitar~q\ & \u4_registro|registro\(1))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u5_fsm|habilitar~q\,
	datac => \u4_registro|registro\(1),
	combout => \u4_registro|registro~5_combout\);

-- Location: FF_X1_Y23_N23
\u4_registro|registro[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u4_registro|registro[1]~1_combout\,
	asdata => \u4_registro|registro~5_combout\,
	clrn => \botones[0]~input_o\,
	sload => \u5_fsm|ALT_INV_cargar~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u4_registro|registro\(1));

-- Location: LCCOMB_X1_Y23_N16
\u4_registro|registro~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u4_registro|registro~3_combout\ = (!\llaves[0]~input_o\ & (\u5_fsm|cargar~q\ & (\llaves[1]~input_o\ $ (!\llaves[2]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010000100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \llaves[1]~input_o\,
	datab => \llaves[0]~input_o\,
	datac => \llaves[2]~input_o\,
	datad => \u5_fsm|cargar~q\,
	combout => \u4_registro|registro~3_combout\);

-- Location: LCCOMB_X1_Y23_N26
\u4_registro|registro~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u4_registro|registro~4_combout\ = (\u4_registro|registro~3_combout\) # ((!\u5_fsm|cargar~q\ & \u4_registro|registro\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111101010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u5_fsm|cargar~q\,
	datac => \u4_registro|registro\(1),
	datad => \u4_registro|registro~3_combout\,
	combout => \u4_registro|registro~4_combout\);

-- Location: LCCOMB_X1_Y23_N4
\u4_registro|registro[3]~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u4_registro|registro[3]~2_combout\ = (\u5_fsm|habilitar~q\) # (\u5_fsm|cargar~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u5_fsm|habilitar~q\,
	datad => \u5_fsm|cargar~q\,
	combout => \u4_registro|registro[3]~2_combout\);

-- Location: FF_X1_Y23_N27
\u4_registro|registro[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u4_registro|registro~4_combout\,
	clrn => \botones[0]~input_o\,
	ena => \u4_registro|registro[3]~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u4_registro|registro\(2));

-- Location: FF_X1_Y23_N21
\u4_registro|registro[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u4_registro|registro[3]~0_combout\,
	asdata => \u4_registro|registro\(2),
	clrn => \botones[0]~input_o\,
	sload => \u5_fsm|ALT_INV_cargar~q\,
	ena => \u4_registro|registro[3]~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u4_registro|registro\(3));

-- Location: LCCOMB_X2_Y23_N24
\u5_fsm|Selector2~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u5_fsm|Selector2~0_combout\ = (\u5_fsm|habilitar~0_combout\ & (((\u5_fsm|estado.s_punto~q\ & !\u2_divisor|tick~q\)) # (!\u4_registro|registro\(3)))) # (!\u5_fsm|habilitar~0_combout\ & (((\u5_fsm|estado.s_punto~q\ & !\u2_divisor|tick~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010001011110010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u5_fsm|habilitar~0_combout\,
	datab => \u4_registro|registro\(3),
	datac => \u5_fsm|estado.s_punto~q\,
	datad => \u2_divisor|tick~q\,
	combout => \u5_fsm|Selector2~0_combout\);

-- Location: FF_X2_Y23_N25
\u5_fsm|estado.s_punto\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u5_fsm|Selector2~0_combout\,
	clrn => \botones[0]~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u5_fsm|estado.s_punto~q\);

-- Location: LCCOMB_X2_Y23_N18
\u5_fsm|Selector3~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u5_fsm|Selector3~0_combout\ = (\u5_fsm|habilitar~0_combout\ & ((\u4_registro|registro\(3)) # ((\u5_fsm|estado.s_raya1~q\ & !\u2_divisor|tick~q\)))) # (!\u5_fsm|habilitar~0_combout\ & (((\u5_fsm|estado.s_raya1~q\ & !\u2_divisor|tick~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u5_fsm|habilitar~0_combout\,
	datab => \u4_registro|registro\(3),
	datac => \u5_fsm|estado.s_raya1~q\,
	datad => \u2_divisor|tick~q\,
	combout => \u5_fsm|Selector3~0_combout\);

-- Location: FF_X2_Y23_N19
\u5_fsm|estado.s_raya1\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u5_fsm|Selector3~0_combout\,
	clrn => \botones[0]~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u5_fsm|estado.s_raya1~q\);

-- Location: LCCOMB_X2_Y23_N28
\u5_fsm|estado.s_raya2~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u5_fsm|estado.s_raya2~feeder_combout\ = \u5_fsm|estado.s_raya1~q\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \u5_fsm|estado.s_raya1~q\,
	combout => \u5_fsm|estado.s_raya2~feeder_combout\);

-- Location: FF_X2_Y23_N29
\u5_fsm|estado.s_raya2\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u5_fsm|estado.s_raya2~feeder_combout\,
	clrn => \botones[0]~input_o\,
	ena => \u2_divisor|tick~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u5_fsm|estado.s_raya2~q\);

-- Location: LCCOMB_X2_Y23_N22
\u5_fsm|estado.s_raya3~feeder\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u5_fsm|estado.s_raya3~feeder_combout\ = \u5_fsm|estado.s_raya2~q\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \u5_fsm|estado.s_raya2~q\,
	combout => \u5_fsm|estado.s_raya3~feeder_combout\);

-- Location: FF_X2_Y23_N23
\u5_fsm|estado.s_raya3\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u5_fsm|estado.s_raya3~feeder_combout\,
	clrn => \botones[0]~input_o\,
	ena => \u2_divisor|tick~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u5_fsm|estado.s_raya3~q\);

-- Location: LCCOMB_X2_Y23_N10
\u5_fsm|estado~18\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u5_fsm|estado~18_combout\ = (\u5_fsm|estado.s_punto~q\) # (\u5_fsm|estado.s_raya3~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110011111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u5_fsm|estado.s_punto~q\,
	datac => \u5_fsm|estado.s_raya3~q\,
	combout => \u5_fsm|estado~18_combout\);

-- Location: FF_X2_Y23_N11
\u5_fsm|estado.s_pausa\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u5_fsm|estado~18_combout\,
	clrn => \botones[0]~input_o\,
	ena => \u2_divisor|tick~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u5_fsm|estado.s_pausa~q\);

-- Location: LCCOMB_X2_Y23_N0
\u5_fsm|WideOr7\ : cycloneiii_lcell_comb
-- Equation(s):
-- \u5_fsm|WideOr7~combout\ = (!\u5_fsm|estado.s_pausa~q\ & (\u5_fsm|estado.s_espera~q\ & !\u5_fsm|estado.s_evaluar~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u5_fsm|estado.s_pausa~q\,
	datac => \u5_fsm|estado.s_espera~q\,
	datad => \u5_fsm|estado.s_evaluar~q\,
	combout => \u5_fsm|WideOr7~combout\);

-- Location: FF_X2_Y23_N1
\u5_fsm|led\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj_50~inputclkctrl_outclk\,
	d => \u5_fsm|WideOr7~combout\,
	clrn => \botones[0]~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u5_fsm|led~q\);

ww_led_rojo(0) <= \led_rojo[0]~output_o\;
END structure;


