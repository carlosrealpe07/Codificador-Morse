transcript on
if {[file exists rtl_work]} {
	vdel -lib rtl_work -all
}
vlib rtl_work
vmap work rtl_work

vcom -93 -work work {C:/altera/13.1/Parcial Individual (Morse) - Carlos Realpe/cont_longitud/cont_longitud.vhd}
vcom -93 -work work {C:/altera/13.1/Parcial Individual (Morse) - Carlos Realpe/divisor_frec/divisor_frec.vhd}
vcom -93 -work work {C:/altera/13.1/Parcial Individual (Morse) - Carlos Realpe/fsm_control/fsm_control.vhd}
vcom -93 -work work {C:/altera/13.1/Parcial Individual (Morse) - Carlos Realpe/reg_desplazamiento/reg_desplazamiento.vhd}
vcom -93 -work work {C:/altera/13.1/Parcial Individual (Morse) - Carlos Realpe/sel_letra/sel_letra.vhd}
vcom -93 -work work {C:/altera/13.1/Parcial Individual (Morse) - Carlos Realpe/top_morse/top_morse.vhd}

