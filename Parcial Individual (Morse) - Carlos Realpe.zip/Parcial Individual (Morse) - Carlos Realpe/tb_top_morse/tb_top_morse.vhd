library ieee;
use ieee.std_logic_1164.all;

-- la entidad de un testbench siempre va vacia
entity tb_top_morse is
end tb_top_morse;

architecture prueba of tb_top_morse is

    -- 1. declaracion del componente a probar (dut - design under test)
    component top_morse
        port (
            reloj_50 : in  std_logic;
            llaves   : in  std_logic_vector(2 downto 0);
            botones  : in  std_logic_vector(1 downto 0);
            led_rojo : out std_logic_vector(0 downto 0)
        );
    end component;

    -- 2. señales internas para conectar al dut
    signal c_reloj   : std_logic := '0';
    signal c_llaves  : std_logic_vector(2 downto 0) := "000";
    signal c_botones : std_logic_vector(1 downto 0) := "11"; -- botones sin presionar (pull-up)
    signal c_led     : std_logic_vector(0 downto 0);

    -- constante para el periodo del reloj de 50 mhz (1 / 50mhz = 20 ns)
    constant periodo : time := 20 ns;

begin

    -- 3. instanciacion del dut
    dut: top_morse
        port map (
            reloj_50 => c_reloj,
            llaves   => c_llaves,
            botones  => c_botones,
            led_rojo => c_led
        );

    -- 4. generacion del reloj continuo (estimulo automatico)
    proceso_reloj: process
    begin
        c_reloj <= '0';
        wait for periodo / 2;
        c_reloj <= '1';
        wait for periodo / 2;
    end process;

    -- 5. generacion de estimulos (vectores de prueba)
    proceso_estimulos: process
    begin
        -- a) reset inicial del sistema (botones(0) activo bajo)
        c_botones(0) <= '0';
        wait for 100 ns;
        c_botones(0) <= '1';
        wait for 100 ns;

        -- b) prueba 1: transmitir la letra 'a' (.-)
        -- 'a' es "000" en los interruptores
        c_llaves <= "000"; 
        
        -- presionar boton de inicio (botones(1) activo bajo)
        c_botones(1) <= '0';
        wait for 100 ns;
        c_botones(1) <= '1'; -- soltar boton

        -- nota: la letra 'a' dura en morse:
        -- 0.5s (punto) + 0.5s (pausa) + 1.5s (raya) = 2.5 segundod
        -- en una simulacion real a 50mhz, esperar 2.5s tardara mucho tiempo de maquina
        -- entonces se usa el comando "run 3 sec" en modelsim para ver la onda completa
        wait for 3 sec;

        -- c) prueba 2: transmitir la letra 'e' (.)
        -- 'e' es "100" en los interruptores
        c_llaves <= "100"; 
        
        -- presionar boton de inicio
        c_botones(1) <= '0';
        wait for 100 ns;
        c_botones(1) <= '1';

        wait for 1 sec;

        -- fin de la simulacion
        wait;
    end process;

end prueba;