-- Copyright (C) 1991-2013 Altera Corporation
-- Your use of Altera Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Altera Program License 
-- Subscription Agreement, Altera MegaCore Function License 
-- Agreement, or other applicable license agreement, including, 
-- without limitation, that your use is for the sole purpose of 
-- programming logic devices manufactured by Altera and sold by 
-- Altera or its authorized distributors.  Please refer to the 
-- applicable agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus II 64-Bit"
-- VERSION "Version 13.1.0 Build 162 10/23/2013 SJ Web Edition"

-- DATE "10/12/2026 15:19:49"

-- 
-- Device: Altera EP3C16F484C6 Package FBGA484
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY ALTERA;
LIBRARY CYCLONEIII;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE CYCLONEIII.CYCLONEIII_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	reg_desplazamiento IS
    PORT (
	reloj : IN std_logic;
	rst : IN std_logic;
	cargar : IN std_logic;
	habilitar : IN std_logic;
	datos_in : IN std_logic_vector(3 DOWNTO 0);
	bit_salida : OUT std_logic
	);
END reg_desplazamiento;

-- Design Ports Information
-- bit_salida	=>  Location: PIN_R10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datos_in[3]	=>  Location: PIN_V6,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- cargar	=>  Location: PIN_R9,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- reloj	=>  Location: PIN_G2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- rst	=>  Location: PIN_G1,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- habilitar	=>  Location: PIN_T8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datos_in[2]	=>  Location: PIN_V5,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datos_in[1]	=>  Location: PIN_R11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datos_in[0]	=>  Location: PIN_T9,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF reg_desplazamiento IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_reloj : std_logic;
SIGNAL ww_rst : std_logic;
SIGNAL ww_cargar : std_logic;
SIGNAL ww_habilitar : std_logic;
SIGNAL ww_datos_in : std_logic_vector(3 DOWNTO 0);
SIGNAL ww_bit_salida : std_logic;
SIGNAL \reloj~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \rst~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \bit_salida~output_o\ : std_logic;
SIGNAL \reloj~input_o\ : std_logic;
SIGNAL \reloj~inputclkctrl_outclk\ : std_logic;
SIGNAL \cargar~input_o\ : std_logic;
SIGNAL \datos_in[3]~input_o\ : std_logic;
SIGNAL \datos_in[2]~input_o\ : std_logic;
SIGNAL \datos_in[1]~input_o\ : std_logic;
SIGNAL \datos_in[0]~input_o\ : std_logic;
SIGNAL \habilitar~input_o\ : std_logic;
SIGNAL \registro~4_combout\ : std_logic;
SIGNAL \rst~input_o\ : std_logic;
SIGNAL \rst~inputclkctrl_outclk\ : std_logic;
SIGNAL \registro~3_combout\ : std_logic;
SIGNAL \registro[3]~1_combout\ : std_logic;
SIGNAL \registro~2_combout\ : std_logic;
SIGNAL \registro~0_combout\ : std_logic;
SIGNAL registro : std_logic_vector(3 DOWNTO 0);

BEGIN

ww_reloj <= reloj;
ww_rst <= rst;
ww_cargar <= cargar;
ww_habilitar <= habilitar;
ww_datos_in <= datos_in;
bit_salida <= ww_bit_salida;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\reloj~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \reloj~input_o\);

\rst~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \rst~input_o\);

-- Location: IOOBUF_X1_Y0_N16
\bit_salida~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => registro(3),
	devoe => ww_devoe,
	o => \bit_salida~output_o\);

-- Location: IOIBUF_X0_Y14_N1
\reloj~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_reloj,
	o => \reloj~input_o\);

-- Location: CLKCTRL_G4
\reloj~inputclkctrl\ : cycloneiii_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \reloj~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \reloj~inputclkctrl_outclk\);

-- Location: IOIBUF_X1_Y0_N29
\cargar~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_cargar,
	o => \cargar~input_o\);

-- Location: IOIBUF_X1_Y0_N1
\datos_in[3]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datos_in(3),
	o => \datos_in[3]~input_o\);

-- Location: IOIBUF_X3_Y0_N29
\datos_in[2]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datos_in(2),
	o => \datos_in[2]~input_o\);

-- Location: IOIBUF_X3_Y0_N1
\datos_in[1]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datos_in(1),
	o => \datos_in[1]~input_o\);

-- Location: IOIBUF_X1_Y0_N8
\datos_in[0]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datos_in(0),
	o => \datos_in[0]~input_o\);

-- Location: IOIBUF_X1_Y0_N22
\habilitar~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_habilitar,
	o => \habilitar~input_o\);

-- Location: LCCOMB_X2_Y1_N12
\registro~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \registro~4_combout\ = (\cargar~input_o\ & (\datos_in[0]~input_o\)) # (!\cargar~input_o\ & (((!\habilitar~input_o\ & registro(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datos_in[0]~input_o\,
	datab => \habilitar~input_o\,
	datac => registro(0),
	datad => \cargar~input_o\,
	combout => \registro~4_combout\);

-- Location: IOIBUF_X0_Y14_N8
\rst~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_rst,
	o => \rst~input_o\);

-- Location: CLKCTRL_G2
\rst~inputclkctrl\ : cycloneiii_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \rst~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \rst~inputclkctrl_outclk\);

-- Location: FF_X2_Y1_N13
\registro[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \registro~4_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => registro(0));

-- Location: LCCOMB_X2_Y1_N10
\registro~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \registro~3_combout\ = (\cargar~input_o\ & (\datos_in[1]~input_o\)) # (!\cargar~input_o\ & ((registro(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \cargar~input_o\,
	datac => \datos_in[1]~input_o\,
	datad => registro(0),
	combout => \registro~3_combout\);

-- Location: LCCOMB_X2_Y1_N0
\registro[3]~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \registro[3]~1_combout\ = (\habilitar~input_o\) # (\cargar~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \habilitar~input_o\,
	datad => \cargar~input_o\,
	combout => \registro[3]~1_combout\);

-- Location: FF_X2_Y1_N11
\registro[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \registro~3_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	ena => \registro[3]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => registro(1));

-- Location: LCCOMB_X2_Y1_N2
\registro~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \registro~2_combout\ = (\cargar~input_o\ & (\datos_in[2]~input_o\)) # (!\cargar~input_o\ & ((registro(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \cargar~input_o\,
	datac => \datos_in[2]~input_o\,
	datad => registro(1),
	combout => \registro~2_combout\);

-- Location: FF_X2_Y1_N3
\registro[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \registro~2_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	ena => \registro[3]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => registro(2));

-- Location: LCCOMB_X2_Y1_N28
\registro~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \registro~0_combout\ = (\cargar~input_o\ & (\datos_in[3]~input_o\)) # (!\cargar~input_o\ & ((registro(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \cargar~input_o\,
	datac => \datos_in[3]~input_o\,
	datad => registro(2),
	combout => \registro~0_combout\);

-- Location: FF_X2_Y1_N29
\registro[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \reloj~inputclkctrl_outclk\,
	d => \registro~0_combout\,
	clrn => \rst~inputclkctrl_outclk\,
	ena => \registro[3]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => registro(3));

ww_bit_salida <= \bit_salida~output_o\;
END structure;


