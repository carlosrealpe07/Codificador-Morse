library ieee;
use ieee.std_logic_1164.all;


entity reg_desplazamiento is
    port (
        reloj      : in  std_logic;
        rst        : in  std_logic;
        cargar     : in  std_logic;
        habilitar  : in  std_logic; -- señal para desplazar
        datos_in   : in  std_logic_vector(3 downto 0);
        bit_salida : out std_logic
    );
end reg_desplazamiento;


architecture arch_reg_desplazamiento of reg_desplazamiento is

    signal registro : std_logic_vector(3 downto 0);
	 
begin
    process(reloj, rst)
    begin
        if rst = '0' then
            registro <= (others => '0');
        elsif rising_edge(reloj) then
            if cargar = '1' then
                registro <= datos_in;
            elsif habilitar = '1' then
                -- desplaza bits a la izquierda y rellena con 0
                registro <= registro(2 downto 0) & '0'; 
            end if;
        end if;
    end process;

    -- envia el bit mas significativo a la fsm
    bit_salida <= registro(3);
	 
end arch_reg_desplazamiento;